/**
 * Configurações Gerais da Loja ZNK STORE01
 * Todos os dados de contato, redes sociais e parâmetros comerciais
 * podem ser configurados facilmente neste arquivo.
 */

export const STORE_CONFIG = {
  name: 'ZNK STORE01',
  tagline: 'ESTILO QUE FALA POR VOCÊ.',
  subtagline: 'Moda masculina para quem busca qualidade, atitude e personalidade.',
  location: 'Rio Branco - AC, Brasil',
  city: 'Rio Branco',
  state: 'AC',
  
  // WhatsApp configurável (DDD 68 - Acre)
  whatsappNumber: '5568999887766',
  whatsappDisplay: '(68) 99988-7766',
  
  // Instagram configurável
  instagramHandle: '@znk.store01',
  instagramUrl: 'https://instagram.com/znk.store01',
  
  // Endereço e Funcionamento
  address: 'Rua Principal, Centro - Rio Branco, AC',
  openingHours: 'Segunda a Sábado: 09h às 19h',
  
  // Regras de Envio e Frete
  freeShippingThreshold: 199.00,
  localShippingRate: 10.00, // Entrega expressa em Rio Branco
  nationalShippingRate: 24.90,
  
  // Chave PIX (fictícia para o protótipo)
  pixKey: 'contato@znkstore01.com.br',
  pixDiscountPercent: 5, // 5% de desconto no PIX
};

/**
 * Função utilitária para gerar link de WhatsApp com mensagem pré-formatada
 */
export function generateWhatsAppLink(message: string): string {
  const cleanNumber = STORE_CONFIG.whatsappNumber.replace(/\D/g, '');
  const encodedMessage = encodeURIComponent(message);
  return `https://wa.me/${cleanNumber}?text=${encodedMessage}`;
}

/**
 * Formata valores para o padrão Real Brasileiro (R$ XX,XX)
 */
export function formatCurrency(amount: number): string {
  return amount.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });
}
