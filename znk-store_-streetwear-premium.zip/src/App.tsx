/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CartProvider, useCart } from './context/CartContext';
import { AdminProvider } from './context/AdminContext';
import { AnnouncementBar } from './components/AnnouncementBar';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { CategoriesSection } from './components/CategoriesSection';
import { ProductsSection } from './components/ProductsSection';
import { PromoSection } from './components/PromoSection';
import { ReviewsSection } from './components/ReviewsSection';
import { AboutSection } from './components/AboutSection';
import { InstagramSection } from './components/InstagramSection';
import { Footer } from './components/Footer';
import { ProductModal } from './components/ProductModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { Toast } from './components/Toast';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { ProductCategory, Product } from './types';

function StoreMain() {
  const { selectedProduct, openProductModal, closeProductModal } = useCart();
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>('Todos');
  const [searchQuery, setSearchQuery] = useState('');

  const handleSelectCategory = (category: ProductCategory) => {
    setSelectedCategory(category);
    const prodSection = document.getElementById('produtos');
    if (prodSection) {
      prodSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToProducts = () => {
    const prodSection = document.getElementById('produtos');
    if (prodSection) {
      prodSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToPromos = () => {
    const promoSection = document.getElementById('promocoes');
    if (promoSection) {
      promoSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#08090D] text-zinc-100 flex flex-col font-sans selection:bg-[#0066FF] selection:text-white">
      {/* Top Banner */}
      <AnnouncementBar />

      {/* Header / Navbar */}
      <Navbar 
        onSearchClick={scrollToProducts} 
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
      />

      <main className="flex-grow">
        {/* Hero Section */}
        <Hero 
          onShopClick={scrollToProducts}
          onPromoClick={scrollToPromos}
        />

        {/* Categories Section ("ENCONTRE SEU ESTILO") */}
        <CategoriesSection 
          onSelectCategory={handleSelectCategory}
        />

        {/* Main Catalog / Best Sellers ("MAIS VENDIDOS") */}
        <ProductsSection
          onViewProduct={openProductModal}
          selectedCategory={selectedCategory}
          setSelectedCategory={setSelectedCategory}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
        />

        {/* Promotional Offers Section ("OFERTAS DA ZNK") */}
        <PromoSection 
          onViewProduct={openProductModal}
        />

        {/* Customer Feedbacks ("QUEM COMPRA, APROVA.") */}
        <ReviewsSection />

        {/* About the Brand ("MAIS QUE ROUPA. É ESTILO.") */}
        <AboutSection />

        {/* Instagram Lookbook Community ("SIGA A ZNK") */}
        <InstagramSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Modals & Overlays */}
      <ProductModal
        product={selectedProduct}
        onClose={closeProductModal}
        onSelectProduct={(p: Product) => openProductModal(p)}
      />

      <CartDrawer />

      <CheckoutModal />

      <FloatingWhatsApp />

      <Toast />

      {/* Admin Panel (Full-Featured Store Management) */}
      <AdminDashboard />
    </div>
  );
}

export default function App() {
  return (
    <AdminProvider>
      <CartProvider>
        <StoreMain />
      </CartProvider>
    </AdminProvider>
  );
}
