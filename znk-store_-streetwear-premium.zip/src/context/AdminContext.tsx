import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import { OrderConfirmationData, OrderStatus, AdminActivityLog, Product } from '../types';
import { INITIAL_ORDERS } from '../data/initialOrders';
import { PRODUCTS } from '../data/products';

export interface AdminProduct extends Product {
  costPrice: number; // Custo de fabricação/compra para apuração do lucro real
}

interface AdminContextType {
  // Navigation & Auth
  isAdminOpen: boolean;
  setIsAdminOpen: (open: boolean) => void;
  isAuthenticated: boolean;
  login: (password: string) => boolean;
  logout: () => void;

  // Orders Management
  orders: OrderConfirmationData[];
  updateOrderStatus: (orderId: string, newStatus: OrderStatus) => void;
  deleteOrder: (orderId: string) => void;
  addOrder: (order: OrderConfirmationData) => void;

  // Inventory Management
  inventory: AdminProduct[];
  updateProductStock: (productId: string, newStock: number) => void;
  updateProductPrice: (productId: string, newPrice: number, newCost?: number) => void;

  // Logs
  logs: AdminActivityLog[];

  // Financial KPIs & Analytics
  analytics: {
    totalRevenue: number;
    totalProfit: number;
    profitMarginPercent: number;
    totalOrdersCount: number;
    deliveredCount: number;
    pendingCount: number;
    inTransitCount: number;
    averageTicket: number;
    totalItemsSold: number;
    paymentBreakdown: {
      pixTotal: number;
      pixCount: number;
      cardTotal: number;
      cardCount: number;
      cashTotal: number;
      cashCount: number;
    };
    lowStockItemsCount: number;
    topSellingProducts: { name: string; quantity: number; revenue: number }[];
  };

  // Reset demo
  resetDataToDefaults: () => void;
}

const ORDERS_STORAGE_KEY = 'znk_store_orders_v2';
const INVENTORY_STORAGE_KEY = 'znk_store_inventory_v2';
const LOGS_STORAGE_KEY = 'znk_store_logs_v2';
const AUTH_STORAGE_KEY = 'znk_store_admin_auth_v2';

const AdminContext = createContext<AdminContextType | undefined>(undefined);

export const AdminProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
      return localStorage.getItem(AUTH_STORAGE_KEY) === 'true';
    } catch {
      return false;
    }
  });

  // Orders State
  const [orders, setOrders] = useState<OrderConfirmationData[]>(() => {
    try {
      const saved = localStorage.getItem(ORDERS_STORAGE_KEY);
      return saved ? JSON.parse(saved) : INITIAL_ORDERS;
    } catch {
      return INITIAL_ORDERS;
    }
  });

  // Inventory State with Cost Price (average cost ~42-45% of retail price)
  const [inventory, setInventory] = useState<AdminProduct[]>(() => {
    try {
      const saved = localStorage.getItem(INVENTORY_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
      return PRODUCTS.map((p) => ({
        ...p,
        costPrice: Math.round(p.price * 0.42),
      }));
    } catch {
      return PRODUCTS.map((p) => ({
        ...p,
        costPrice: Math.round(p.price * 0.42),
      }));
    }
  });

  // Activity Logs
  const [logs, setLogs] = useState<AdminActivityLog[]>(() => {
    try {
      const saved = localStorage.getItem(LOGS_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
      return [
        {
          id: 'log-1',
          action: 'Pedido Entregue com Sucesso',
          timestamp: '06/10/2026 14:22',
          type: 'shipping',
          details: 'Pedido #ZNK-94812 entregue para Matheus Albuquerque no Bairro Bosque (Rio Branco).',
        },
        {
          id: 'log-2',
          action: 'Saiu para Entrega (Motoboy)',
          timestamp: '06/10/2026 16:45',
          type: 'shipping',
          details: 'Pedido #ZNK-94813 despachado para entrega no Bairro Cerâmica.',
        },
        {
          id: 'log-3',
          action: 'Pagamento PIX Confirmado',
          timestamp: '06/10/2026 18:10',
          type: 'payment',
          details: 'Recebido R$ 246,90 via PIX de Lucas Ferreira Mendes.',
        },
        {
          id: 'log-4',
          action: 'Estoque Atualizado',
          timestamp: '06/10/2026 19:00',
          type: 'stock',
          details: 'Reposição confirmada de 18 unidades do drop de camisetas oversized no estoque de Rio Branco.',
        },
      ];
    } catch {
      return [];
    }
  });

  // Persistence
  useEffect(() => {
    try {
      localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(orders));
    } catch (e) {
      console.error(e);
    }
  }, [orders]);

  useEffect(() => {
    try {
      localStorage.setItem(INVENTORY_STORAGE_KEY, JSON.stringify(inventory));
    } catch (e) {
      console.error(e);
    }
  }, [inventory]);

  useEffect(() => {
    try {
      localStorage.setItem(LOGS_STORAGE_KEY, JSON.stringify(logs));
    } catch (e) {
      console.error(e);
    }
  }, [logs]);

  useEffect(() => {
    try {
      localStorage.setItem(AUTH_STORAGE_KEY, isAuthenticated ? 'true' : 'false');
    } catch (e) {
      console.error(e);
    }
  }, [isAuthenticated]);

  // Auth functions (Password: "znk01" or "1234" or quick login)
  const login = (password: string): boolean => {
    const clean = password.trim().toLowerCase();
    if (clean === 'znk01' || clean === '1234' || clean === 'admin' || clean === '') {
      setIsAuthenticated(true);
      addLog({
        action: 'Acesso ao Painel ADM',
        type: 'settings',
        details: 'Lojista ZNK STORE01 autenticado com sucesso no painel de controle.',
      });
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAuthenticated(false);
  };

  const addLog = (entry: Omit<AdminActivityLog, 'id' | 'timestamp'>) => {
    const now = new Date().toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
    const newLog: AdminActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: now,
      ...entry,
    };
    setLogs((prev) => [newLog, ...prev.slice(0, 49)]);
  };

  // Orders Management
  const updateOrderStatus = (orderId: string, newStatus: OrderStatus) => {
    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.orderId === orderId) {
          const updated = { ...ord, status: newStatus };
          addLog({
            action: `Status alterado para "${newStatus.toUpperCase()}"`,
            type: newStatus === 'entregue' || newStatus === 'saiu_para_entrega' ? 'shipping' : 'order',
            details: `Pedido #${ord.orderId} (${ord.customer.fullName}) atualizado para ${newStatus}.`,
          });
          return updated;
        }
        return ord;
      })
    );
  };

  const deleteOrder = (orderId: string) => {
    setOrders((prev) => prev.filter((ord) => ord.orderId !== orderId));
    addLog({
      action: 'Pedido Excluído',
      type: 'order',
      details: `Pedido #${orderId} removido do sistema pelo administrador.`,
    });
  };

  const addOrder = (order: OrderConfirmationData) => {
    // Calculate cost and profit
    const estimatedCost = order.items.reduce((acc, item) => {
      const invProd = inventory.find((p) => p.id === item.product.id);
      const unitCost = invProd?.costPrice || Math.round(item.product.price * 0.42);
      return acc + unitCost * item.quantity;
    }, 0);

    const calculatedProfit = Math.max(0, order.total - estimatedCost);

    const enrichedOrder: OrderConfirmationData = {
      ...order,
      cost: estimatedCost,
      profit: calculatedProfit,
    };

    setOrders((prev) => [enrichedOrder, ...prev]);

    // Deduct stock in inventory
    order.items.forEach((item) => {
      setInventory((prevInv) =>
        prevInv.map((p) => {
          if (p.id === item.product.id) {
            return { ...p, stock: Math.max(0, p.stock - item.quantity) };
          }
          return p;
        })
      );
    });

    addLog({
      action: 'Novo Pedido Recebido no Site',
      type: 'order',
      details: `Pedido #${order.orderId} de R$ ${order.total.toFixed(2)} por ${order.customer.fullName} (${order.customer.neighborhood}, Rio Branco).`,
    });
  };

  // Inventory Management
  const updateProductStock = (productId: string, newStock: number) => {
    setInventory((prev) =>
      prev.map((p) => {
        if (p.id === productId) {
          addLog({
            action: 'Estoque Ajustado Manualmente',
            type: 'stock',
            details: `Estoque de "${p.name}" alterado de ${p.stock} para ${newStock} un.`,
          });
          return { ...p, stock: newStock };
        }
        return p;
      })
    );
  };

  const updateProductPrice = (productId: string, newPrice: number, newCost?: number) => {
    setInventory((prev) =>
      prev.map((p) => {
        if (p.id === productId) {
          addLog({
            action: 'Preço/Custo Atualizado',
            type: 'settings',
            details: `"${p.name}": Novo preço de venda R$ ${newPrice.toFixed(2)}${newCost ? `, custo R$ ${newCost.toFixed(2)}` : ''}.`,
          });
          return {
            ...p,
            price: newPrice,
            costPrice: newCost !== undefined ? newCost : p.costPrice,
          };
        }
        return p;
      })
    );
  };

  const resetDataToDefaults = () => {
    setOrders(INITIAL_ORDERS);
    setInventory(
      PRODUCTS.map((p) => ({
        ...p,
        costPrice: Math.round(p.price * 0.42),
      }))
    );
    addLog({
      action: 'Dados Restaurados',
      type: 'settings',
      details: 'Métricas e estoque restaurados para o padrão de demonstração.',
    });
  };

  // Complete Financial Analytics & Profit KPIs
  const analytics = useMemo(() => {
    const validOrders = orders.filter((o) => o.status !== 'cancelado');
    const totalRevenue = validOrders.reduce((sum, o) => sum + o.total, 0);
    const totalCost = validOrders.reduce((sum, o) => sum + (o.cost || o.total * 0.42), 0);
    const totalProfit = Math.max(0, totalRevenue - totalCost);
    const profitMarginPercent = totalRevenue > 0 ? (totalProfit / totalRevenue) * 100 : 0;
    const averageTicket = validOrders.length > 0 ? totalRevenue / validOrders.length : 0;

    let totalItemsSold = 0;
    const productSalesMap: Record<string, { name: string; quantity: number; revenue: number }> = {};

    validOrders.forEach((ord) => {
      ord.items.forEach((item) => {
        totalItemsSold += item.quantity;
        const pId = item.product.id;
        if (!productSalesMap[pId]) {
          productSalesMap[pId] = {
            name: item.product.name,
            quantity: 0,
            revenue: 0,
          };
        }
        productSalesMap[pId].quantity += item.quantity;
        productSalesMap[pId].revenue += item.product.price * item.quantity;
      });
    });

    const topSellingProducts = Object.values(productSalesMap).sort(
      (a, b) => b.quantity - a.quantity
    );

    const pixOrders = validOrders.filter((o) => o.customer.paymentMethod === 'pix');
    const cardOrders = validOrders.filter((o) => o.customer.paymentMethod === 'credit_card');
    const cashOrders = validOrders.filter((o) => o.customer.paymentMethod === 'cash_on_delivery');

    const paymentBreakdown = {
      pixTotal: pixOrders.reduce((sum, o) => sum + o.total, 0),
      pixCount: pixOrders.length,
      cardTotal: cardOrders.reduce((sum, o) => sum + o.total, 0),
      cardCount: cardOrders.length,
      cashTotal: cashOrders.reduce((sum, o) => sum + o.total, 0),
      cashCount: cashOrders.length,
    };

    const lowStockItemsCount = inventory.filter((p) => p.stock <= 5).length;

    return {
      totalRevenue,
      totalProfit,
      profitMarginPercent,
      totalOrdersCount: orders.length,
      deliveredCount: orders.filter((o) => o.status === 'entregue').length,
      pendingCount: orders.filter((o) => o.status === 'pendente' || o.status === 'pago').length,
      inTransitCount: orders.filter((o) => o.status === 'saiu_para_entrega' || o.status === 'separando').length,
      averageTicket,
      totalItemsSold,
      paymentBreakdown,
      lowStockItemsCount,
      topSellingProducts,
    };
  }, [orders, inventory]);

  return (
    <AdminContext.Provider
      value={{
        isAdminOpen,
        setIsAdminOpen,
        isAuthenticated,
        login,
        logout,
        orders,
        updateOrderStatus,
        deleteOrder,
        addOrder,
        inventory,
        updateProductStock,
        updateProductPrice,
        logs,
        analytics,
        resetDataToDefaults,
      }}
    >
      {children}
    </AdminContext.Provider>
  );
};

export const useAdmin = () => {
  const context = useContext(AdminContext);
  if (!context) {
    throw new Error('useAdmin must be used within an AdminProvider');
  }
  return context;
};
