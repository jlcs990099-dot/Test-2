export type ProductCategory = 
  | 'Todos'
  | 'Camisetas'
  | 'Oversized'
  | 'Shorts'
  | 'Conjuntos'
  | 'Acessórios';

export type ProductSize = 'P' | 'M' | 'G' | 'GG';

export interface Product {
  id: string;
  name: string;
  category: Exclude<ProductCategory, 'Todos'>;
  description: string;
  details?: string[];
  fabric?: string;
  price: number;
  originalPrice?: number;
  discountPercent?: number;
  images: string[];
  sizes: ProductSize[];
  rating: number;
  reviewsCount: number;
  stock: number;
  isBestSeller?: boolean;
  isPromo?: boolean;
  isNewRelease?: boolean;
}

export interface CartItem {
  product: Product;
  size: ProductSize;
  quantity: number;
}

export interface Review {
  id: string;
  name: string;
  city: string;
  rating: number;
  comment: string;
  productBought: string;
  date: string;
  avatarUrl?: string;
  verified: boolean;
}

export interface CategoryInfo {
  id: Exclude<ProductCategory, 'Todos'>;
  title: string;
  subtitle: string;
  image: string;
  itemCount: number;
}

export interface CheckoutForm {
  fullName: string;
  whatsapp: string;
  email: string;
  cep: string;
  state: string;
  city: string;
  neighborhood: string;
  street: string;
  number: string;
  complement: string;
  paymentMethod: 'pix' | 'credit_card' | 'cash_on_delivery';
  notes?: string;
}

export type OrderStatus = 
  | 'pendente' 
  | 'pago' 
  | 'separando' 
  | 'saiu_para_entrega' 
  | 'entregue' 
  | 'cancelado';

export interface OrderConfirmationData {
  orderId: string;
  customer: CheckoutForm;
  items: CartItem[];
  subtotal: number;
  discount: number;
  shipping: number;
  total: number;
  cost?: number;
  profit?: number;
  status: OrderStatus;
  createdAt: string;
}

export interface AdminActivityLog {
  id: string;
  action: string;
  timestamp: string;
  type: 'order' | 'payment' | 'stock' | 'shipping' | 'settings';
  details: string;
}

