import { Product } from '../types';

import vansTshirtImg from '../assets/images/znk_vans_tshirt_1791343151402.jpg';
import synthFlameImg from '../assets/images/znk_synth_flame_1791343261222.jpg';
import nikeSkeletonImg from '../assets/images/znk_nike_skeleton_1791343183511.jpg';
import chronicBiggieImg from '../assets/images/znk_chronic_biggie_1791343173890.jpg';
import nikeBasketballImg from '../assets/images/znk_nike_basketball_1791343242095.jpg';
import manoFlerEyesImg from '../assets/images/znk_manofler_eyes_1791343201538.jpg';
import chronicMadonnaImg from '../assets/images/znk_chronic_madonna_1791343252090.jpg';
import tupacRedImg from '../assets/images/znk_tupac_red_1791343193572.jpg';
import capsCollectionImg from '../assets/images/znk_caps_collection_1791343211074.jpg';
import fullDropFlatlayImg from '../assets/images/znk_full_drop_flatlay_1791343218856.jpg';

import conjuntoHighCoImg from '../assets/images/znk_conjunto_highco_1791343982298.jpg';
import conjuntoFlamengoImg from '../assets/images/znk_conjunto_flamengo_1791343991903.jpg';
import fullDropCapsShirtsImg from '../assets/images/znk_full_drop_caps_shirts_1791344001861.jpg';

export const PRODUCTS: Product[] = [
  {
    id: 'znk-vans-01',
    name: 'Camiseta Oversized Vans Original Checkerboard Black',
    category: 'Oversized',
    description: 'Camiseta oversized legítima streetwear em algodão pesado blackout. Estampa dorsal autêntica Vans Original Checkerboard Company Since 1966 com detalhes em ossos no clássico skate style. Acompanha etiqueta de autenticidade ZNK.',
    details: [
      'Modelagem: Oversized autêntica com caimento solto e estruturado',
      'Estampa costas: Vans Checkerboard Company Since 1966 em silk plastisol',
      'Gola: Ribana canelada 3cm anti-deformação',
      'Costura: Reforço duplo ombro a ombro',
      'Tag e etiqueta oficial preservadas'
    ],
    fabric: '100% Algodão Penteado Heavyweight 260g',
    price: 139.90,
    originalPrice: 179.90,
    discountPercent: 22,
    images: [
      vansTshirtImg,
      fullDropFlatlayImg,
    ],
    sizes: ['P', 'M', 'G', 'GG'],
    rating: 5.0,
    reviewsCount: 42,
    stock: 12,
    isBestSeller: true,
    isPromo: true,
  },
  {
    id: 'znk-synth-02',
    name: 'Camiseta Oversized Synth Flame "Forgive Me" Dark Grey',
    category: 'Oversized',
    description: 'Peça de destaque com grafismo underground em chamas verde neon e contorno roxo. Lettering SYNTH Forgive Me com tag emborrachada exclusiva. Visual imponente e contemporâneo.',
    details: [
      'Modelagem: Oversized Street Drop 2026',
      'Estampa: Grafismo chamas neon em alta definição',
      'Acabamento: Lavagem especial Dark Charcoal',
      'Gola canelada grossa com caimento perfeito nos ombros'
    ],
    fabric: '100% Algodão Heavyweight Penteado 260g',
    price: 149.90,
    originalPrice: 189.90,
    discountPercent: 21,
    images: [
      synthFlameImg,
      capsCollectionImg,
      fullDropFlatlayImg,
    ],
    sizes: ['P', 'M', 'G', 'GG'],
    rating: 4.9,
    reviewsCount: 37,
    stock: 9,
    isBestSeller: true,
    isPromo: true,
  },
  {
    id: 'znk-nike-skel-03',
    name: 'Camiseta Street Nike Skeleton Lady "Just Do It" White',
    category: 'Camisetas',
    description: 'Camiseta streetwear branca premium com estampa dorsal do logo Nike em tipografia cursiva roxa e arte gráfica Day of the Dead / Catrina segurando lata de spray. Arte urbana de respeito.',
    details: [
      'Modelagem: Street Fit estruturada',
      'Estampa: Ilustração artística detalhada com silk toque zero',
      'Costuras reforçadas que não torcem após lavagem',
      'Acompanha tag original ZNK STORE01'
    ],
    fabric: '100% Algodão Egípcio 200g Fio 30.1',
    price: 129.90,
    originalPrice: 159.90,
    discountPercent: 19,
    images: [
      nikeSkeletonImg,
      fullDropFlatlayImg,
    ],
    sizes: ['P', 'M', 'G', 'GG'],
    rating: 4.9,
    reviewsCount: 31,
    stock: 15,
    isBestSeller: true,
    isPromo: true,
  },
  {
    id: 'znk-chronic-big-04',
    name: 'Camiseta Oversized Chronic No. 11 Biggie Smalls Purple',
    category: 'Oversized',
    description: 'Homenagem icônica à lenda do rap The Notorious B.I.G. em tom roxo profundo. Estampa comic retrô de Biggie jogando dados vermelhos no clássico círculo amarelo com tipografia Chronic 420c.',
    details: [
      'Modelagem: Oversized autêntica com manga ampla até o cotovelo',
      'Estampa: Biggie Smalls cartoon comic em silk screen de alta durabilidade',
      'Cor: Roxo Imperial profundo (Deep Purple)',
      'Gola reforçada de 3cm com ribana premium'
    ],
    fabric: '100% Algodão Penteado Grosso 260g',
    price: 149.90,
    originalPrice: 189.90,
    discountPercent: 21,
    images: [
      chronicBiggieImg,
      fullDropFlatlayImg,
    ],
    sizes: ['P', 'M', 'G', 'GG'],
    rating: 5.0,
    reviewsCount: 48,
    stock: 10,
    isBestSeller: true,
    isPromo: true,
  },
  {
    id: 'znk-manofler-05',
    name: 'Camiseta Oversized Mano Fler "O Choro Regou o Sonho" Black',
    category: 'Oversized',
    description: 'Poesia e vivência das ruas. Estampa marcante nas costas com olhos vermelhos em chamas chorando sangue e a frase: "O choro regou o sonho - Me corrija se eu estiver errado, mas em tempos difíceis que a gente encontra quem é de verdade."',
    details: [
      'Colaboração / Linha: Mano Fler Street Soul',
      'Estampa: Olhos em chamas vermelhas e tipografia gótica nas costas',
      'Caimento: Boxy Oversized reto e pesado',
      'Tecido premium com toque peletizado'
    ],
    fabric: '100% Algodão Premium Heavy 260g',
    price: 139.90,
    originalPrice: 179.90,
    discountPercent: 22,
    images: [
      manoFlerEyesImg,
      fullDropFlatlayImg,
    ],
    sizes: ['P', 'M', 'G', 'GG'],
    rating: 4.9,
    reviewsCount: 53,
    stock: 8,
    isBestSeller: true,
    isPromo: true,
  },
  {
    id: 'znk-chronic-mary-06',
    name: 'Camiseta Oversized Chronic Virgin Mary Praying Purple',
    category: 'Oversized',
    description: 'Estética Chicano / Tattoo clássica com arte sacra urbana da Virgem Maria em oração, anjos barrocos, rosas e chamas vermelhas sobre base roxa vibrante. Uma das peças mais procuradas do drop.',
    details: [
      'Modelagem: Oversized legítima',
      'Arte: Tattoo Chicano Style com riqueza extrema de detalhes',
      'Ribana na gola com elastano anti-esgarçamento'
    ],
    fabric: '100% Algodão Penteado 260g',
    price: 149.90,
    originalPrice: 189.90,
    discountPercent: 21,
    images: [
      chronicMadonnaImg,
      fullDropFlatlayImg,
    ],
    sizes: ['P', 'M', 'G', 'GG'],
    rating: 4.8,
    reviewsCount: 26,
    stock: 11,
    isPromo: true,
  },
  {
    id: 'znk-nike-bball-07',
    name: 'Camiseta Street Nike Basketball Street Court Purple',
    category: 'Camisetas',
    description: 'Vibe das quadras de rua de basquete. Estampa nas costas de mão segurando a bola de basquete com o swoosh da Nike estilizado e detalhes geométricos em verde neon e laranja.',
    details: [
      'Modelagem: Street Regular confortável',
      'Estampa: Basquete urbano com cores vibrantes contrastantes',
      'Tecido leve e respirável para o clima quente de Rio Branco'
    ],
    fabric: '100% Algodão Penteado Macio 200g',
    price: 129.90,
    originalPrice: 159.90,
    discountPercent: 19,
    images: [
      nikeBasketballImg,
      fullDropFlatlayImg,
    ],
    sizes: ['P', 'M', 'G', 'GG'],
    rating: 4.8,
    reviewsCount: 29,
    stock: 14,
  },
  {
    id: 'znk-tupac-08',
    name: 'Camiseta Street 2Pac Back Tupac Shakur Red',
    category: 'Camisetas',
    description: 'Tributo ao ícone imortal do hip hop Tupac Shakur em malha vermelha vibrante. Retrato de 2Pac com bandana, coroa e lettering "15 Years Later 2PAC BACK". Pura atitude e história do rap.',
    details: [
      'Estampa: Retrato realista de Tupac Shakur nas costas',
      'Cor: Vermelho Cardinal intenso com alta solidez',
      'Caimento street com comprimento padrão'
    ],
    fabric: '100% Algodão Fio 30.1 Penteado',
    price: 139.90,
    originalPrice: 169.90,
    discountPercent: 18,
    images: [
      tupacRedImg,
      fullDropFlatlayImg,
    ],
    sizes: ['P', 'M', 'G', 'GG'],
    rating: 4.9,
    reviewsCount: 34,
    stock: 13,
    isNewRelease: true,
  },
  {
    id: 'znk-caps-09',
    name: 'Coleção Bonés 5-Panel & Dad Hat Anth Co / Origin Streetwear',
    category: 'Acessórios',
    description: 'Linha exclusiva de bonés estruturados e 5-panels da ZNK STORE01. Modelos em preto com lettering graffiti, branco clássico e rosa pastel. Fita strapback ajustável de alta qualidade.',
    details: [
      'Modelos: 5-Panel e Dad Hat Aba Curva/Reta',
      'Bordados: Tipografia urbana Anth Co / Origin Th Co em relevo',
      'Ajuste: Fecho fita strapback traseiro com fivela de engate',
      'Cores disponíveis: Preto Grafite, Branco Puro e Rosa Street'
    ],
    fabric: '100% Sarja e Tactel Hidrorrepelente de Alta Resistência',
    price: 89.90,
    originalPrice: 119.90,
    discountPercent: 25,
    images: [
      capsCollectionImg,
      synthFlameImg,
    ],
    sizes: ['M'], // Tamanho único ajustável
    rating: 5.0,
    reviewsCount: 61,
    stock: 24,
    isBestSeller: true,
    isPromo: true,
  },
  {
    id: 'znk-combo-10',
    name: 'Combo Especial Drop Streetwear ZNK (2 Peças à Escolha)',
    category: 'Conjuntos',
    description: 'Monte seu combo exclusivo com qualquer 2 camisetas ou 1 camiseta + 1 boné da nossa seleção real de 18 peças. Economize garantindo o look mais respeitado de Rio Branco.',
    details: [
      'Combo: Leve 2 peças do drop oficial ZNK',
      'Válido para Oversized Vans, 2Pac, Biggie, Nike ou Boné',
      'Acompanha adesivo colecionável e sacola personalizada da loja'
    ],
    fabric: 'Malhas Algodão Heavyweight 260g',
    price: 249.90,
    originalPrice: 329.90,
    discountPercent: 24,
    images: [
      fullDropFlatlayImg,
      vansTshirtImg,
      capsCollectionImg,
    ],
    sizes: ['P', 'M', 'G', 'GG'],
    rating: 5.0,
    reviewsCount: 77,
    stock: 10,
    isBestSeller: true,
    isPromo: true,
  },
  {
    id: 'znk-conjunto-highco',
    name: 'Conjunto Streetwear Nike Skeleton + Short High Co. Black',
    category: 'Conjuntos',
    description: 'Look completo pronto de alta atitude streetwear: Camiseta Branca Nike Skeleton Lady "Just Do It" em algodão macio com arte gráfica nas costas + Short Tactel High Co. Black com escrita cursiva branca bordada no joelho. Peças originais do estoque físico.',
    details: [
      'Combo: 1 Camiseta Streetwear + 1 Short Tactel High Co.',
      'Camiseta: Estampa Catrina / Caveira com lata de spray e tipografia Nike cursiva',
      'Short: Tecido tactel secagem rápida, cós elástico e bordado High Co.',
      'Perfeito para o calor e o rolê urbano em Rio Branco'
    ],
    fabric: 'Camiseta Algodão Egípcio 200g | Short Tactel Streetwear 100% Poliamida',
    price: 229.90,
    originalPrice: 289.90,
    discountPercent: 21,
    images: [
      conjuntoHighCoImg,
      nikeSkeletonImg,
      fullDropCapsShirtsImg,
    ],
    sizes: ['P', 'M', 'G', 'GG'],
    rating: 5.0,
    reviewsCount: 64,
    stock: 8,
    isBestSeller: true,
    isPromo: true,
  },
  {
    id: 'znk-conjunto-flamengo',
    name: 'Conjunto Treino Fla Off-White Dourado + Short Bege + Slide',
    category: 'Conjuntos',
    description: 'O combo esportivo urbano mais procurado da ZNK: Camisa de Treino Flamengo Off-White e Marrom com detalhes e patrocinador Betano em Dourado + Short Tactel Adidas Bege Areia com logo esportivo + Sandália Slide esportiva preta com tira texturizada.',
    details: [
      'Combo Completo: Camisa de Treino + Short Tactel + Chinelo Slide',
      'Camisa: Tecido Climacool respirável com frisos dourados no ombro',
      'Short: Tactel leve com cordão de ajuste na cintura e bolso traseiro',
      'Chinelo: Solado macio anatômico com logo estrela dourada'
    ],
    fabric: 'Poliéster Dry-Fit Esportivo + Tactel Hidrorrepelente',
    price: 259.90,
    originalPrice: 329.90,
    discountPercent: 21,
    images: [
      conjuntoFlamengoImg,
      fullDropCapsShirtsImg,
    ],
    sizes: ['P', 'M', 'G', 'GG'],
    rating: 5.0,
    reviewsCount: 89,
    stock: 7,
    isBestSeller: true,
    isPromo: true,
  },
  {
    id: 'znk-drop-caps-shirts',
    name: 'Drop Completo ZNK (Camisetas Oversized + Bonés 5-Panel)',
    category: 'Conjuntos',
    description: 'Novo drop geral da loja física ZNK STORE01 em Rio Branco - AC. Coleção completa com 18 opções de camisetas oversized (Vans, Chronic, Nike, 2Pac, Mano Fler) com bonés 5-Panel Anth Co e Origin sobrepostos. Escolha seu kit com desconto especial de lançamento.',
    details: [
      'Estoque Físico Real: 18 modelos de camisetas + 7 modelos de bonés',
      'Atendimento direto pelo WhatsApp para escolher combinações de cores e tamanhos',
      'Pronta entrega em Rio Branco - AC e envio imediato para todo o Brasil'
    ],
    fabric: 'Algodão Penteado Heavyweight 260g e Sarja',
    price: 279.90,
    originalPrice: 359.90,
    discountPercent: 22,
    images: [
      fullDropCapsShirtsImg,
      fullDropFlatlayImg,
      capsCollectionImg,
    ],
    sizes: ['P', 'M', 'G', 'GG'],
    rating: 5.0,
    reviewsCount: 95,
    stock: 12,
    isBestSeller: true,
    isPromo: true,
  },
  {
    id: 'znk-short-highco',
    name: 'Short Tactel High Co. Black Streetwear',
    category: 'Shorts',
    description: 'Bermuda em tactel de secagem rápida com bordado cursivo branco High Co. no joelho. Peça autêntica do estoque físico ZNK, ideal para o clima de Rio Branco.',
    details: [
      'Modelagem: Acima do joelho padrão streetwear',
      'Bordado: Escrita cursiva High Co. em linha branca de alta precisão',
      'Cós: Elástico reforçado com cordão de ajuste interno',
      'Foto real da peça no estoque físico da loja'
    ],
    fabric: '100% Poliamida Tactel Hidrorrepelente',
    price: 119.90,
    originalPrice: 149.90,
    discountPercent: 20,
    images: [
      conjuntoHighCoImg,
    ],
    sizes: ['P', 'M', 'G', 'GG'],
    rating: 4.9,
    reviewsCount: 38,
    stock: 14,
    isPromo: true,
  },
  {
    id: 'znk-short-bege',
    name: 'Short Tactel Adidas Bege Areia Sportswear',
    category: 'Shorts',
    description: 'Short esportivo urbano em tom areia / bege claro com logo diagonal esportivo branco na perna esquerda. Cós em elástico com amarração frontal e bolsos laterais funcionais.',
    details: [
      'Modelagem: Confortável para praia, treino ou rua',
      'Cor: Areia / Bege Claro fosco',
      'Secagem rápida e tecido ultraleve'
    ],
    fabric: 'Tactel Esportivo 100% Poliéster Dry',
    price: 119.90,
    originalPrice: 149.90,
    discountPercent: 20,
    images: [
      conjuntoFlamengoImg,
    ],
    sizes: ['P', 'M', 'G', 'GG'],
    rating: 4.8,
    reviewsCount: 29,
    stock: 11,
    isPromo: true,
  }
];
