import { OrderConfirmationData } from '../types';
import { PRODUCTS } from './products';

export const INITIAL_ORDERS: OrderConfirmationData[] = [
  {
    orderId: 'ZNK-94812',
    customer: {
      fullName: 'Matheus Albuquerque Lima',
      whatsapp: '(68) 99201-4455',
      email: 'matheus.albuquerque@gmail.com',
      cep: '69900-120',
      state: 'Acre (AC)',
      city: 'Rio Branco',
      neighborhood: 'Bosque',
      street: 'Rua Benjamin Constant',
      number: '482',
      complement: 'Apto 302',
      paymentMethod: 'pix',
      notes: 'Entregar preferencialmente após as 14h',
    },
    items: [
      { product: PRODUCTS[0], size: 'G', quantity: 1 }, // Vans Checkerboard
      { product: PRODUCTS[8], size: 'M', quantity: 1 }, // Boné Anth Co
    ],
    subtotal: 229.80,
    discount: 11.49, // 5% PIX
    shipping: 0.00, // Frete grátis > 199
    total: 218.31,
    cost: 95.00,
    profit: 123.31,
    status: 'entregue',
    createdAt: '06/10/2026 14:22',
  },
  {
    orderId: 'ZNK-94813',
    customer: {
      fullName: 'Gabriel Vasconcelos',
      whatsapp: '(68) 99981-2233',
      email: 'gabriel.vasconcelos@hotmail.com',
      cep: '69905-040',
      state: 'Acre (AC)',
      city: 'Rio Branco',
      neighborhood: 'Cerâmica',
      street: 'Avenida Ceará',
      number: '1250',
      complement: '',
      paymentMethod: 'credit_card',
      notes: 'Chamar no portão preto',
    },
    items: [
      { product: PRODUCTS[10], size: 'M', quantity: 1 }, // Conjunto High Co
    ],
    subtotal: 229.90,
    discount: 0.00,
    shipping: 0.00,
    total: 229.90,
    cost: 105.00,
    profit: 124.90,
    status: 'saiu_para_entrega',
    createdAt: '06/10/2026 16:45',
  },
  {
    orderId: 'ZNK-94814',
    customer: {
      fullName: 'Lucas Ferreira Mendes',
      whatsapp: '(68) 98411-9988',
      email: 'lucas.fmendes@gmail.com',
      cep: '69914-220',
      state: 'Acre (AC)',
      city: 'Rio Branco',
      neighborhood: 'Floresta',
      street: 'Rua Estrada da Floresta',
      number: '89',
      complement: 'Casa dos fundos',
      paymentMethod: 'pix',
      notes: 'Pagamento PIX realizado imediatamente',
    },
    items: [
      { product: PRODUCTS[11], size: 'GG', quantity: 1 }, // Conjunto Flamengo + Slide
    ],
    subtotal: 259.90,
    discount: 13.00,
    shipping: 0.00,
    total: 246.90,
    cost: 118.00,
    profit: 128.90,
    status: 'separando',
    createdAt: '06/10/2026 18:10',
  },
  {
    orderId: 'ZNK-94815',
    customer: {
      fullName: 'Rafael Souza Pinheiro',
      whatsapp: '(68) 99912-3344',
      email: 'rafa.souza@outlook.com',
      cep: '69900-010',
      state: 'Acre (AC)',
      city: 'Rio Branco',
      neighborhood: 'Centro',
      street: 'Rua Marechal Deodoro',
      number: '310',
      complement: 'Sala Comercial 04',
      paymentMethod: 'cash_on_delivery',
      notes: 'Troco para R$ 200,00',
    },
    items: [
      { product: PRODUCTS[3], size: 'M', quantity: 1 }, // Chronic Biggie
    ],
    subtotal: 149.90,
    discount: 0.00,
    shipping: 10.00, // Frete local
    total: 159.90,
    cost: 65.00,
    profit: 94.90,
    status: 'pago',
    createdAt: '06/10/2026 19:30',
  },
  {
    orderId: 'ZNK-94816',
    customer: {
      fullName: 'João Vitor Sena',
      whatsapp: '(68) 99288-7766',
      email: 'jvsena@gmail.com',
      cep: '69918-090',
      state: 'Acre (AC)',
      city: 'Rio Branco',
      neighborhood: 'Tangará',
      street: 'Rua Rio de Janeiro',
      number: '540',
      complement: '',
      paymentMethod: 'pix',
      notes: 'Aguardando envio do motoboy',
    },
    items: [
      { product: PRODUCTS[4], size: 'G', quantity: 1 }, // Mano Fler olhos vermelhos
      { product: PRODUCTS[2], size: 'G', quantity: 1 }, // Nike Skeleton
    ],
    subtotal: 269.80,
    discount: 13.49,
    shipping: 0.00,
    total: 256.31,
    cost: 115.00,
    profit: 141.31,
    status: 'pendente',
    createdAt: '06/10/2026 20:15',
  },
];
