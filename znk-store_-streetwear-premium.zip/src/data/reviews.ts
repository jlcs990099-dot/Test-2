import { Review } from '../types';

/**
 * DADOS DEMONSTRATIVOS DE FEEDBACKS / AVALIAÇÕES
 * Estes dados são depoimentos de compradores.
 * Avatares usam iniciais limpas sem nenhuma imagem externa.
 */
export const REVIEWS: Review[] = [
  {
    id: 'rev-01',
    name: 'Matheus Albuquerque',
    city: 'Rio Branco - AC (Bairro Bosque)',
    rating: 5,
    comment: 'Pedi a camiseta oversized Vans e o short High Co. A qualidade do algodão é de outro patamar, super pesada e a gola não deforma. Chegou no mesmo dia aqui em Rio Branco!',
    productBought: 'Camiseta Oversized Vans + Short High Co.',
    date: 'Há 3 dias',
    verified: true,
  },
  {
    id: 'rev-02',
    name: 'Gabriel Vasconcelos',
    city: 'Rio Branco - AC (Cerâmica)',
    rating: 5,
    comment: 'A melhor loja de streetwear do Acre sem dúvidas. O atendimento pelo WhatsApp tirou todas minhas dúvidas de tamanho. O caimento da oversized Biggie ficou impecável.',
    productBought: 'Camiseta Oversized Chronic Biggie Smalls',
    date: 'Há 1 semana',
    verified: true,
  },
  {
    id: 'rev-03',
    name: 'Lucas Ferreira',
    city: 'Cruzeiro do Sul - AC',
    rating: 5,
    comment: 'Peguei o conjunto do Flamengo com a sandália slide. É muita presença e estilo. O tecido é macio e estruturado, não desbota na lavagem. ZNK tá de parabéns pelo bom gosto nas peças!',
    productBought: 'Conjunto Treino Fla Dourado + Slide',
    date: 'Há 2 semanas',
    verified: true,
  },
  {
    id: 'rev-04',
    name: 'Rafael Mendes',
    city: 'Porto Velho - RO',
    rating: 5,
    comment: 'Comprei pela primeira vez e fiquei impressionado com o capricho da embalagem e a velocidade do envio. Os bonés 5-Panel têm acabamento premium. Recomendo demais!',
    productBought: 'Boné 5-Panel Anth Co + Camiseta 2Pac',
    date: 'Há 3 semanas',
    verified: true,
  },
];
