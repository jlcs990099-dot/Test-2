import { CategoryInfo } from '../types';

import vansTshirtImg from '../assets/images/znk_vans_tshirt_1791343151402.jpg';
import nikeSkeletonImg from '../assets/images/znk_nike_skeleton_1791343183511.jpg';
import capsCollectionImg from '../assets/images/znk_caps_collection_1791343211074.jpg';
import conjuntoHighCoImg from '../assets/images/znk_conjunto_highco_1791343982298.jpg';
import conjuntoFlamengoImg from '../assets/images/znk_conjunto_flamengo_1791343991903.jpg';

export const CATEGORIES: CategoryInfo[] = [
  {
    id: 'Camisetas',
    title: 'Camisetas',
    subtitle: 'Streetwear essencial com caimento estruturado',
    image: nikeSkeletonImg,
    itemCount: 4,
  },
  {
    id: 'Oversized',
    title: 'Oversized',
    subtitle: 'Modelagem ampla autêntica e gramatura pesada',
    image: vansTshirtImg,
    itemCount: 5,
  },
  {
    id: 'Shorts',
    title: 'Shorts',
    subtitle: 'Bermudas High Co e tactel esportivo',
    image: conjuntoFlamengoImg,
    itemCount: 2,
  },
  {
    id: 'Conjuntos',
    title: 'Conjuntos',
    subtitle: 'Combos High Co, Fla & drops oficiais',
    image: conjuntoHighCoImg,
    itemCount: 4,
  },
  {
    id: 'Acessórios',
    title: 'Acessórios',
    subtitle: 'Bonés 5-panel e dad hats Anth Co / Origin',
    image: capsCollectionImg,
    itemCount: 1,
  },
];
