import React, { useState, useEffect } from 'react';
import { 
  ShoppingBag, 
  Search, 
  Menu, 
  X, 
  Instagram, 
  Phone, 
  MapPin,
  ArrowRight,
  ShieldCheck,
  Lock
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAdmin } from '../context/AdminContext';
import { STORE_CONFIG, generateWhatsAppLink } from '../config/storeConfig';

interface NavbarProps {
  onSearchClick: () => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onSearchClick, searchQuery, setSearchQuery }) => {
  const { totalItems, setIsCartOpen } = useCart();
  const { setIsAdminOpen } = useAdmin();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isSearchInputOpen, setIsSearchInputOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Início', href: '#inicio' },
    { label: 'Produtos', href: '#produtos' },
    { label: 'Categorias', href: '#categorias' },
    { label: 'Promoções', href: '#promocoes' },
    { label: 'Sobre nós', href: '#sobre' },
    { label: 'Feedbacks', href: '#feedbacks' },
  ];

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSearchInputOpen(false);
    const prodSection = document.getElementById('produtos');
    if (prodSection) {
      prodSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <header 
        className={`sticky top-0 z-40 transition-all duration-300 ${
          isScrolled 
            ? 'bg-[#08090D]/95 backdrop-blur-md border-b border-zinc-800 shadow-xl py-3' 
            : 'bg-[#08090D]/80 backdrop-blur-sm border-b border-zinc-800/60 py-4'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-4">
            
            {/* Mobile Hamburger Button */}
            <div className="flex items-center lg:hidden">
              <button
                type="button"
                onClick={() => setMobileMenuOpen(true)}
                className="p-2 -ml-2 text-zinc-300 hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0066FF] rounded-lg"
                aria-label="Abrir menu"
              >
                <Menu className="w-6 h-6" />
              </button>
            </div>

            {/* Brand Logo */}
            <div className="flex-shrink-0 flex items-center">
              <a 
                href="#inicio" 
                onClick={(e) => handleLinkClick(e, '#inicio')}
                className="group flex items-center gap-2"
              >
                <div className="w-9 h-9 rounded-lg bg-zinc-950 border border-zinc-700 flex items-center justify-center font-black text-white text-lg tracking-wider group-hover:border-[#0066FF] transition-colors relative overflow-hidden">
                  <span className="relative z-10 text-white font-mono font-bold">Z</span>
                  <div className="absolute inset-0 bg-gradient-to-tr from-[#0066FF]/20 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#0066FF]" />
                </div>
                <div className="flex flex-col">
                  <span className="font-heading font-extrabold text-xl sm:text-2xl tracking-tighter text-white leading-none">
                    ZNK <span className="text-[#0066FF]">STORE01</span>
                  </span>
                  <span className="text-[9px] font-mono tracking-widest text-zinc-400 uppercase -mt-0.5">
                    Rio Branco · AC
                  </span>
                </div>
              </a>
            </div>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center gap-7">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={(e) => handleLinkClick(e, link.href)}
                  className="text-sm font-medium text-zinc-300 hover:text-white transition-colors relative py-1 hover:after:w-full after:w-0 after:h-0.5 after:bg-[#0066FF] after:absolute after:bottom-0 after:left-0 after:transition-all after:duration-200"
                >
                  {link.label}
                  {link.label === 'Promoções' && (
                    <span className="ml-1.5 px-1.5 py-0.5 text-[10px] font-bold bg-[#0066FF]/20 text-[#3385ff] border border-[#0066FF]/40 rounded">
                      OFF
                    </span>
                  )}
                </a>
              ))}
            </nav>

            {/* Action Icons (Search, Cart, Contact) */}
            <div className="flex items-center gap-2 sm:gap-3">
              {/* Search Toggle / Input */}
              <div className="relative">
                {isSearchInputOpen ? (
                  <form onSubmit={handleSearchSubmit} className="flex items-center">
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Buscar camisetas, shorts..."
                      autoFocus
                      className="w-48 sm:w-64 bg-zinc-900 border border-[#0066FF] text-white text-xs rounded-lg px-3 py-1.5 focus:outline-none pr-8"
                    />
                    <button
                      type="button"
                      onClick={() => setIsSearchInputOpen(false)}
                      className="absolute right-2 text-zinc-400 hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </form>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      setIsSearchInputOpen(true);
                      onSearchClick();
                    }}
                    className="p-2 text-zinc-300 hover:text-white hover:bg-zinc-900/60 rounded-lg transition-colors"
                    aria-label="Buscar produtos"
                    title="Buscar na loja"
                  >
                    <Search className="w-5 h-5" />
                  </button>
                )}
              </div>

              {/* Instagram Quick Link */}
              <a
                href={STORE_CONFIG.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="hidden sm:flex p-2 text-zinc-300 hover:text-[#0066FF] hover:bg-zinc-900/60 rounded-lg transition-colors"
                title="Siga no Instagram @znk.store01"
              >
                <Instagram className="w-5 h-5" />
              </a>

              {/* Cart Button */}
              <button
                type="button"
                onClick={() => setIsCartOpen(true)}
                className="relative flex items-center gap-2 px-3 py-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/80 hover:border-[#0066FF] text-white rounded-xl transition-all duration-200 group"
                aria-label={`Carrinho de compras com ${totalItems} itens`}
              >
                <ShoppingBag className="w-5 h-5 text-zinc-300 group-hover:text-[#0066FF] transition-colors" />
                <span className="hidden sm:inline text-xs font-semibold tracking-wider uppercase">
                  Carrinho
                </span>
                {totalItems > 0 && (
                  <span className="inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 text-xs font-bold text-white bg-[#0066FF] rounded-full box-glow-blue-subtle">
                    {totalItems}
                  </span>
                )}
              </button>

              {/* Admin Dashboard Trigger */}
              <button
                type="button"
                onClick={() => setIsAdminOpen(true)}
                className="flex items-center gap-1.5 px-3 py-2 bg-zinc-950 hover:bg-zinc-900 border border-zinc-700/80 hover:border-[#0066FF] text-zinc-300 hover:text-white rounded-xl transition-all text-xs font-semibold"
                title="Painel Administrativo da Loja"
              >
                <Lock className="w-3.5 h-3.5 text-[#0066FF]" />
                <span className="hidden md:inline font-mono text-[11px] uppercase tracking-wider">Painel ADM</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          {/* Backdrop */}
          <div 
            className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
            onClick={() => setMobileMenuOpen(false)}
          />

          {/* Drawer content */}
          <div className="fixed inset-y-0 left-0 w-full max-w-xs bg-[#090A0F] border-r border-zinc-800 p-6 flex flex-col justify-between shadow-2xl z-10 overflow-y-auto">
            <div>
              {/* Drawer Header */}
              <div className="flex items-center justify-between pb-6 border-b border-zinc-800">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-zinc-900 border border-[#0066FF] flex items-center justify-center font-bold text-white text-base">
                    Z
                  </div>
                  <div>
                    <span className="font-heading font-extrabold text-lg text-white">
                      ZNK <span className="text-[#0066FF]">STORE01</span>
                    </span>
                    <p className="text-[10px] text-zinc-400 font-mono">Rio Branco - AC</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-900"
                  aria-label="Fechar menu"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Mobile Search */}
              <div className="mt-5 mb-6">
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    setMobileMenuOpen(false);
                    const prodSection = document.getElementById('produtos');
                    if (prodSection) prodSection.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="relative"
                >
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Buscar produtos..."
                    className="w-full bg-zinc-900 border border-zinc-800 focus:border-[#0066FF] text-white text-sm rounded-xl px-4 py-2.5 pl-10 focus:outline-none"
                  />
                  <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-3.5" />
                </form>
              </div>

              {/* Nav Links */}
              <div className="space-y-1">
                {navLinks.map((link) => (
                  <a
                    key={link.href}
                    href={link.href}
                    onClick={(e) => handleLinkClick(e, link.href)}
                    className="flex items-center justify-between px-3 py-3 rounded-lg text-zinc-200 hover:bg-zinc-900 hover:text-white font-medium text-base transition-colors"
                  >
                    <span>{link.label}</span>
                    <ArrowRight className="w-4 h-4 text-zinc-600" />
                  </a>
                ))}
              </div>

              {/* Quick Badge */}
              <div className="mt-6 p-4 rounded-xl bg-zinc-950 border border-zinc-800/80">
                <div className="flex items-center gap-2 text-xs font-semibold text-[#0066FF] mb-1">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Loja Oficial ZNK</span>
                </div>
                <p className="text-xs text-zinc-400">
                  Moda masculina urbana em Rio Branco - AC com entrega rápida e garantia de qualidade.
                </p>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="pt-6 border-t border-zinc-800 space-y-3">
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  setIsAdminOpen(true);
                }}
                className="w-full flex items-center justify-center gap-2 py-3 bg-black hover:bg-zinc-900 text-white font-bold text-xs uppercase rounded-xl border border-zinc-700/80 transition-colors"
              >
                <Lock className="w-4 h-4 text-[#0066FF]" />
                <span>Painel Administrativo (Lojista)</span>
              </button>

              <a
                href={generateWhatsAppLink('Olá ZNK STORE01! Gostaria de tirar uma dúvida sobre as roupas.')}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2 py-3 bg-[#0066FF] hover:bg-[#0052cc] text-white font-semibold text-sm rounded-xl transition-colors shadow-lg shadow-[#0066FF]/20"
              >
                <Phone className="w-4 h-4" />
                <span>Chamar no WhatsApp</span>
              </a>

              <a
                href={STORE_CONFIG.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2 py-2.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 font-medium text-sm rounded-xl border border-zinc-700/80 transition-colors"
              >
                <Instagram className="w-4 h-4 text-[#0066FF]" />
                <span>Instagram {STORE_CONFIG.instagramHandle}</span>
              </a>

              <div className="flex items-center justify-center gap-1 text-[11px] text-zinc-500 pt-2">
                <MapPin className="w-3.5 h-3.5 text-[#0066FF]" />
                <span>Rio Branco - AC · Brasil</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
