import React from 'react';
import { Check, ShieldCheck, Zap, Headphones, Truck, MapPin } from 'lucide-react';
import fullDropFlatlayImg from '../assets/images/znk_full_drop_flatlay_1791343218856.jpg';
import { ScrollReveal } from './ScrollReveal';

export const AboutSection: React.FC = () => {
  return (
    <section id="sobre" className="py-16 sm:py-24 border-b border-zinc-800/80 relative overflow-hidden bg-zinc-950/40">
      
      {/* Background glow accent */}
      <div className="absolute top-1/2 right-10 -translate-y-1/2 w-80 h-80 bg-[#0066FF]/10 blur-[120px] pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Visual Brand Statement with ScrollReveal */}
          <div className="lg:col-span-5 relative">
            <ScrollReveal duration={750} distance={32}>
              <div className="relative rounded-3xl overflow-hidden border border-zinc-800 bg-zinc-900 aspect-[4/5] shadow-2xl">
                <img
                  src={fullDropFlatlayImg}
                  alt="ZNK STORE01 Estoque Real de Streetwear em Rio Branco - AC"
                  className="w-full h-full object-cover object-center contrast-110 hover:scale-105 transition-all duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" />

                {/* Streetwear brand stamps */}
                <div className="absolute bottom-6 left-6 right-6 p-4 rounded-2xl bg-zinc-950/85 backdrop-blur-md border border-zinc-700/80">
                  <span className="text-[10px] font-mono tracking-widest text-[#0066FF] uppercase font-bold">
                    MANIFESTO DA MARCA
                  </span>
                  <p className="text-sm font-bold text-white font-heading mt-1">
                    Nascida no Norte, feita para dominar qualquer rua do Brasil.
                  </p>
                  <div className="flex items-center gap-2 mt-2 text-[11px] text-zinc-400 font-mono">
                    <MapPin className="w-3.5 h-3.5 text-[#0066FF]" />
                    <span>Rio Branco - Acre · Desde 2024</span>
                  </div>
                </div>
              </div>
            </ScrollReveal>
          </div>

          {/* Right Column: Story & 4 Pillars with ScrollReveal */}
          <div className="lg:col-span-7 space-y-6">
            <ScrollReveal duration={700} distance={28} delay={100}>
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-2.5 h-0.5 bg-[#0066FF]" />
                  <span className="text-xs font-mono uppercase tracking-widest text-[#0066FF] font-semibold">
                    NOSSA HISTÓRIA
                  </span>
                </div>

                <h2 className="text-3xl sm:text-5xl font-black text-white uppercase font-heading tracking-tight leading-tight">
                  MAIS QUE ROUPA. <br />
                  <span className="text-[#0066FF] text-glow-blue">É ESTILO.</span>
                </h2>

                <p className="text-zinc-300 text-base sm:text-lg leading-relaxed mt-4">
                  A <strong>ZNK STORE01</strong> nasceu da paixão pela cultura urbana, streetwear contemporâneo e moda masculina autêntica. Localizada no coração de <strong>Rio Branco - AC</strong>, nossa missão é entregar peças que fogem do comum — unindo modelagens amplas, tecidos estruturados de alta gramatura e atitude pura.
                </p>

                <p className="text-zinc-400 text-sm leading-relaxed mt-3">
                  Acreditamos que a roupa é a primeira forma de comunicação visual. Por isso, cada costura, cada gola canelada e cada detalhe é rigorosamente selecionado para quem valoriza presença e personalidade em qualquer ocasião.
                </p>
              </div>
            </ScrollReveal>

            {/* 4 Core Pillars Required */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
              
              {/* Qualidade */}
              <ScrollReveal delay={150} duration={600} distance={20}>
                <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800/90 flex items-start gap-3.5 hover:border-[#0066FF] transition-colors h-full">
                  <div className="w-9 h-9 rounded-xl bg-[#0066FF]/15 border border-[#0066FF]/40 flex items-center justify-center text-[#3385ff] shrink-0 mt-0.5">
                    <Check className="w-5 h-5 font-bold" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white font-heading uppercase flex items-center gap-1.5">
                      <span>Qualidade</span>
                    </h4>
                    <p className="text-xs text-zinc-400 mt-1 leading-normal">
                      Malhas pesadas (260g+), algodão penteado macio e golas reforçadas que não deformam.
                    </p>
                  </div>
                </div>
              </ScrollReveal>

              {/* Estilo */}
              <ScrollReveal delay={200} duration={600} distance={20}>
                <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800/90 flex items-start gap-3.5 hover:border-[#0066FF] transition-colors h-full">
                  <div className="w-9 h-9 rounded-xl bg-[#0066FF]/15 border border-[#0066FF]/40 flex items-center justify-center text-[#3385ff] shrink-0 mt-0.5">
                    <Check className="w-5 h-5 font-bold" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white font-heading uppercase flex items-center gap-1.5">
                      <span>Estilo</span>
                    </h4>
                    <p className="text-xs text-zinc-400 mt-1 leading-normal">
                      Modelagem oversized legítima, cortes modernos e estampas com identidade única.
                    </p>
                  </div>
                </div>
              </ScrollReveal>

              {/* Atendimento */}
              <ScrollReveal delay={250} duration={600} distance={20}>
                <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800/90 flex items-start gap-3.5 hover:border-[#0066FF] transition-colors h-full">
                  <div className="w-9 h-9 rounded-xl bg-[#0066FF]/15 border border-[#0066FF]/40 flex items-center justify-center text-[#3385ff] shrink-0 mt-0.5">
                    <Check className="w-5 h-5 font-bold" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white font-heading uppercase flex items-center gap-1.5">
                      <span>Atendimento</span>
                    </h4>
                    <p className="text-xs text-zinc-400 mt-1 leading-normal">
                      Suporte humanizado e ágil diretamente pelo WhatsApp para tirar dúvidas de medidas e pedidos.
                    </p>
                  </div>
                </div>
              </ScrollReveal>

              {/* Envio para todo o Brasil */}
              <ScrollReveal delay={300} duration={600} distance={20}>
                <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800/90 flex items-start gap-3.5 hover:border-[#0066FF] transition-colors h-full">
                  <div className="w-9 h-9 rounded-xl bg-[#0066FF]/15 border border-[#0066FF]/40 flex items-center justify-center text-[#3385ff] shrink-0 mt-0.5">
                    <Check className="w-5 h-5 font-bold" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white font-heading uppercase flex items-center gap-1.5">
                      <span>Envio para todo o Brasil</span>
                    </h4>
                    <p className="text-xs text-zinc-400 mt-1 leading-normal">
                      Entrega expressa em Rio Branco e frete rastreado seguro para todos os estados do país.
                    </p>
                  </div>
                </div>
              </ScrollReveal>

            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
