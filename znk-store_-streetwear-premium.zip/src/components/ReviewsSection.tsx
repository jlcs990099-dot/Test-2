import React from 'react';
import { Star, ShieldCheck, Quote, MapPin } from 'lucide-react';
import { REVIEWS } from '../data/reviews';
import { ScrollReveal } from './ScrollReveal';

export const ReviewsSection: React.FC = () => {
  return (
    <section id="feedbacks" className="py-16 sm:py-24 border-b border-zinc-800/80 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <ScrollReveal duration={650} distance={28}>
          <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-zinc-900 border border-zinc-700/80 rounded-full text-xs text-zinc-300 font-medium mb-3">
              <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
              <span className="font-semibold text-white">4.9 / 5.0 DE SATISFAÇÃO</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white uppercase font-heading tracking-tight">
              QUEM COMPRA, <span className="text-[#0066FF]">APROVA.</span>
            </h2>

            <p className="text-zinc-400 text-sm sm:text-base mt-3">
              Depoimentos reais de clientes que vestem a ZNK em Rio Branco e por todo o Brasil.
            </p>
            
            <p className="text-[11px] text-zinc-500 font-mono mt-1">
              * Dados demonstrativos de avaliação que podem ser customizados pelo lojista.
            </p>
          </div>
        </ScrollReveal>

        {/* Reviews Grid with Staggered Fade-in Up */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {REVIEWS.map((review, index) => (
            <ScrollReveal
              key={review.id}
              delay={index * 90}
              duration={650}
              distance={30}
              className="h-full"
            >
              <div className="p-5 sm:p-6 rounded-2xl bg-zinc-950 border border-zinc-800/90 hover:border-[#0066FF] transition-all duration-300 flex flex-col justify-between hover:shadow-xl hover:shadow-[#0066FF]/10 hover:-translate-y-1 relative group h-full">
                <div>
                  {/* Stars and date */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-1 text-amber-400">
                      {[...Array(review.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-amber-400" />
                      ))}
                    </div>
                    <span className="text-[11px] font-mono text-zinc-500">{review.date}</span>
                  </div>

                  {/* Comment quote */}
                  <p className="text-sm text-zinc-300 leading-relaxed italic mb-6">
                    "{review.comment}"
                  </p>
                </div>

                {/* Reviewer Bio */}
                <div className="pt-4 border-t border-zinc-900 flex items-center gap-3">
                  {review.avatarUrl ? (
                    <img
                      src={review.avatarUrl}
                      alt={review.name}
                      className="w-10 h-10 rounded-full object-cover border border-zinc-700"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-zinc-900 border border-zinc-700 flex items-center justify-center font-bold text-white text-xs">
                      {review.name.charAt(0)}
                    </div>
                  )}

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-xs font-bold text-white truncate font-heading">
                        {review.name}
                      </h4>
                      {review.verified && (
                        <span title="Comprador verificado" className="inline-flex">
                          <ShieldCheck className="w-3.5 h-3.5 text-[#0066FF] shrink-0" />
                        </span>
                      )}
                    </div>

                    <p className="text-[11px] text-zinc-400 flex items-center gap-1 truncate">
                      <MapPin className="w-3 h-3 text-zinc-500 inline shrink-0" />
                      <span>{review.city}</span>
                    </p>
                  </div>
                </div>

              </div>
            </ScrollReveal>
          ))}
        </div>

      </div>
    </section>
  );
};
