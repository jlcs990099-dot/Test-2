import React from 'react';
import { Truck, Sparkles, MapPin } from 'lucide-react';

export const AnnouncementBar: React.FC = () => {
  return (
    <div className="bg-[#050608] border-b border-zinc-800/80 text-zinc-300 text-xs py-2 px-4 select-none">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-zinc-400">
          <MapPin className="w-3.5 h-3.5 text-[#0066FF]" />
          <span>Rio Branco - AC</span>
          <span className="hidden sm:inline text-zinc-600">|</span>
          <span className="hidden sm:inline text-zinc-400">Enviamos para todo o Brasil 🇧🇷</span>
        </div>

        <div className="flex items-center gap-4 mx-auto sm:mx-0 font-medium">
          <span className="flex items-center gap-1.5 text-zinc-200">
            <Truck className="w-3.5 h-3.5 text-[#0066FF]" />
            <span>Frete Grátis acima de R$ 199</span>
          </span>
          <span className="text-zinc-600">·</span>
          <span className="flex items-center gap-1.5 text-zinc-200">
            <Sparkles className="w-3.5 h-3.5 text-[#0066FF]" />
            <span>5% OFF no PIX</span>
          </span>
        </div>

        <div className="hidden lg:flex items-center gap-2 text-zinc-400">
          <span>Atendimento WhatsApp: (68) 99988-7766</span>
        </div>
      </div>
    </div>
  );
};
