import React from 'react';
import { ArrowRight, Tag, ShieldCheck, Truck, Sparkles, MapPin, CheckCircle2 } from 'lucide-react';
import { ScrollReveal } from './ScrollReveal';
import heroBannerImg from '../assets/images/znk_full_drop_caps_shirts_1791344001861.jpg';
import vansTshirtImg from '../assets/images/znk_vans_tshirt_1791343151402.jpg';

interface HeroProps {
  onShopClick: () => void;
  onPromoClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onShopClick, onPromoClick }) => {
  return (
    <section id="inicio" className="relative overflow-hidden pt-6 pb-16 lg:py-20 border-b border-zinc-800/80">
      {/* Background ambient lighting effects */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-[#0066FF]/10 blur-[140px] pointer-events-none rounded-full" />
      <div className="absolute -top-10 right-0 w-96 h-96 bg-[#0052FF]/10 blur-[120px] pointer-events-none rounded-full" />

      {/* Grid Pattern overlay */}
      <div className="absolute inset-0 bg-grid-pattern opacity-15 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Headlines & Call to Actions */}
          <div className="lg:col-span-7">
            <ScrollReveal duration={700} distance={28}>
              <div className="flex flex-col justify-center text-left space-y-6">
                
                {/* Tag / Kicker with Rio Branco origin */}
                <div className="flex flex-wrap items-center gap-3">
                  <div className="inline-flex items-center gap-2 px-3 py-1 bg-zinc-900 border border-zinc-700/80 rounded-full text-xs text-zinc-300 font-medium">
                    <span className="w-2 h-2 rounded-full bg-[#0066FF] animate-pulse" />
                    <span className="font-semibold text-white">NOVA COLEÇÃO 2026</span>
                    <span className="text-zinc-600">·</span>
                    <span className="text-[#3385ff] flex items-center gap-1">
                      <MapPin className="w-3 h-3 inline" /> Rio Branco - AC
                    </span>
                  </div>
                  <span className="text-xs text-zinc-400 font-mono hidden sm:inline">
                    STREETWEAR MASCULINO
                  </span>
                </div>

                {/* Main Headline */}
                <h1 className="text-4xl sm:text-6xl xl:text-7xl font-extrabold tracking-tight text-white leading-[1.08] font-heading uppercase">
                  ESTILO QUE <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-zinc-100 to-zinc-400">
                    FALA POR
                  </span>{' '}
                  <span className="text-[#0066FF] relative inline-block text-glow-blue">
                    VOCÊ.
                    <svg className="absolute -bottom-2 left-0 w-full h-3 text-[#0066FF]" viewBox="0 0 100 12" preserveAspectRatio="none">
                      <path d="M0,8 Q50,0 100,8" fill="none" stroke="currentColor" strokeWidth="3" />
                    </svg>
                  </span>
                </h1>

                {/* Subtitle */}
                <p className="text-base sm:text-lg lg:text-xl text-zinc-400 max-w-2xl font-normal leading-relaxed">
                  Moda masculina para quem busca qualidade, atitude e personalidade.
                  Peças pesadas, modelagens oversized autênticas e corte impecável direto de Rio Branco - AC.
                </p>

                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
                  <button
                    type="button"
                    onClick={onShopClick}
                    className="group relative inline-flex items-center justify-center gap-3 px-8 py-4 bg-[#0066FF] hover:bg-[#0055e6] text-white font-bold text-sm tracking-wider uppercase rounded-xl transition-all duration-200 box-glow-blue shadow-lg shadow-[#0066FF]/25 hover:translate-y-[-1px] active:translate-y-[0px]"
                  >
                    <span>COMPRAR AGORA</span>
                    <ArrowRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-1" />
                  </button>

                  <button
                    type="button"
                    onClick={onPromoClick}
                    className="inline-flex items-center justify-center gap-2.5 px-7 py-4 bg-zinc-900/90 hover:bg-zinc-800 text-zinc-200 hover:text-white font-semibold text-sm tracking-wider uppercase rounded-xl border border-zinc-700/80 hover:border-[#0066FF] transition-all duration-200"
                  >
                    <Tag className="w-4 h-4 text-[#0066FF]" />
                    <span>VER PROMOÇÕES</span>
                  </button>
                </div>

                {/* Trust Highlights */}
                <div className="grid grid-cols-3 gap-3 sm:gap-6 pt-6 border-t border-zinc-800/80 max-w-xl">
                  <div className="flex items-start gap-2.5">
                    <Truck className="w-4 h-4 text-[#0066FF] shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-xs sm:text-sm font-semibold text-white">Envio Rápido</h4>
                      <p className="text-[11px] text-zinc-400">Entrega rápida AC & Brasil</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5">
                    <ShieldCheck className="w-4 h-4 text-[#0066FF] shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-xs sm:text-sm font-semibold text-white">Algodão 100%</h4>
                      <p className="text-[11px] text-zinc-400">Gramatura pesada 260g</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5">
                    <Sparkles className="w-4 h-4 text-[#0066FF] shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-xs sm:text-sm font-semibold text-white">Garantia ZNK</h4>
                      <p className="text-[11px] text-zinc-400">Troca fácil e segura</p>
                    </div>
                  </div>
                </div>

              </div>
            </ScrollReveal>
          </div>

          {/* Right Column: Visual Showcase */}
          <div className="lg:col-span-5 relative">
            <ScrollReveal duration={800} distance={32} delay={120}>
              <div className="relative mx-auto max-w-md lg:max-w-none">
              
              {/* Decorative Frame Elements */}
              <div className="absolute -inset-1.5 rounded-2xl bg-gradient-to-b from-[#0066FF]/40 to-transparent blur-md opacity-60" />
              <div className="absolute -top-3 -right-3 w-16 h-16 border-t-2 border-r-2 border-[#0066FF] rounded-tr-xl z-20 pointer-events-none" />
              <div className="absolute -bottom-3 -left-3 w-16 h-16 border-b-2 border-l-2 border-[#0066FF] rounded-bl-xl z-20 pointer-events-none" />

              {/* Main Image Container */}
              <div className="relative rounded-2xl overflow-hidden border border-zinc-700/80 bg-zinc-950 aspect-[4/5] sm:aspect-[16/18] shadow-2xl">
                <img
                  src={heroBannerImg}
                  alt="ZNK STORE01 - Streetwear masculino e oversized em Rio Branco - AC"
                  className="w-full h-full object-cover object-center scale-[1.02] hover:scale-105 transition-transform duration-700"
                />

                {/* Dark Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />

                {/* Streetwear aesthetic tags placed on image */}
                <div className="absolute top-4 left-4 z-10 flex flex-col gap-1.5">
                  <span className="px-2.5 py-1 bg-black/80 backdrop-blur-md border border-zinc-700/80 text-[10px] font-mono tracking-wider text-zinc-300 rounded uppercase">
                    DROP 01 // 2026
                  </span>
                  <span className="px-2.5 py-1 bg-[#0066FF]/90 backdrop-blur-md text-[10px] font-bold tracking-widest text-white rounded uppercase">
                    URBAN CULTURE
                  </span>
                </div>

                {/* Bottom Card Overlay inside Image */}
                <div className="absolute bottom-4 left-4 right-4 z-10 p-3.5 rounded-xl bg-[#090A0F]/90 backdrop-blur-md border border-zinc-700/80 flex items-center justify-between gap-3 shadow-xl">
                  <div className="flex items-center gap-3 min-w-0">
                    <img 
                      src={vansTshirtImg} 
                      alt="Camiseta Oversized Vans ZNK" 
                      className="w-12 h-12 rounded-lg object-cover border border-[#0066FF]/60 shrink-0" 
                    />
                    <div className="min-w-0">
                      <p className="text-[10px] font-mono tracking-widest text-[#0066FF] uppercase font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                        <span>FOTO REAL DO ESTOQUE</span>
                      </p>
                      <h4 className="text-xs sm:text-sm font-bold text-white font-heading truncate">
                        Oversized Vans Checkerboard
                      </h4>
                      <p className="text-xs text-zinc-300 font-mono">
                        R$ 139,90 <span className="text-[10px] text-zinc-500 line-through">R$ 179,90</span>
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={onShopClick}
                    className="p-2.5 bg-[#0066FF] hover:bg-[#0055e6] text-white rounded-lg transition-colors shrink-0 shadow-md"
                    aria-label="Ver camiseta oversized"
                  >
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

              </div>
            </div>
            </ScrollReveal>
          </div>

        </div>
      </div>
    </section>
  );
};
