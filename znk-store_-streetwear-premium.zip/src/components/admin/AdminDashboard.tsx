import React, { useState } from 'react';
import { 
  BarChart3, 
  Package, 
  DollarSign, 
  TrendingUp, 
  ShoppingBag, 
  Users, 
  Search, 
  SlidersHorizontal, 
  CheckCircle2, 
  Clock, 
  Truck, 
  AlertTriangle, 
  X, 
  ArrowLeft, 
  Phone, 
  MessageCircle, 
  RotateCcw, 
  CreditCard, 
  QrCode, 
  Banknote, 
  ArrowUpRight,
  ShieldCheck,
  Activity,
  Settings,
  Eye,
  Trash2,
  Lock,
  ChevronRight
} from 'lucide-react';
import { useAdmin, AdminProduct } from '../../context/AdminContext';
import { OrderConfirmationData, OrderStatus } from '../../types';
import { formatCurrency, STORE_CONFIG, generateWhatsAppLink } from '../../config/storeConfig';

export const AdminDashboard: React.FC = () => {
  const {
    isAdminOpen,
    setIsAdminOpen,
    isAuthenticated,
    login,
    logout,
    orders,
    updateOrderStatus,
    deleteOrder,
    inventory,
    updateProductStock,
    updateProductPrice,
    logs,
    analytics,
    resetDataToDefaults,
  } = useAdmin();

  // Active Tab
  const [activeTab, setActiveTab] = useState<'dashboard' | 'orders' | 'inventory' | 'finance' | 'logs' | 'settings'>('dashboard');

  // Password Login state
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState(false);

  // Orders Filter & Search
  const [orderSearch, setOrderSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'todos' | OrderStatus>('todos');
  const [selectedOrderDetails, setSelectedOrderDetails] = useState<OrderConfirmationData | null>(null);

  // Inventory Search & Edit
  const [inventorySearch, setInventorySearch] = useState('');
  const [editingProduct, setEditingProduct] = useState<AdminProduct | null>(null);

  if (!isAdminOpen) return null;

  // Handle Login
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const success = login(passwordInput);
    if (!success) {
      setLoginError(true);
    } else {
      setLoginError(false);
      setPasswordInput('');
    }
  };

  const handleQuickLogin = () => {
    login('znk01');
    setLoginError(false);
  };

  // Filtered Orders
  const filteredOrders = orders.filter((ord) => {
    if (statusFilter !== 'todos' && ord.status !== statusFilter) return false;
    if (orderSearch.trim()) {
      const q = orderSearch.toLowerCase();
      const matchId = ord.orderId.toLowerCase().includes(q);
      const matchName = ord.customer.fullName.toLowerCase().includes(q);
      const matchNeigh = ord.customer.neighborhood.toLowerCase().includes(q);
      if (!matchId && !matchName && !matchNeigh) return false;
    }
    return true;
  });

  // Filtered Inventory
  const filteredInventory = inventory.filter((item) => {
    if (inventorySearch.trim()) {
      const q = inventorySearch.toLowerCase();
      return item.name.toLowerCase().includes(q) || item.category.toLowerCase().includes(q);
    }
    return true;
  });

  // Status Badge Colors
  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'entregue':
        return <span className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-emerald-950/80 text-emerald-400 border border-emerald-800/80">Entregue</span>;
      case 'saiu_para_entrega':
        return <span className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-blue-950/80 text-[#3385ff] border border-blue-800/80">Saiu p/ Entrega</span>;
      case 'separando':
        return <span className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-purple-950/80 text-purple-400 border border-purple-800/80">Separando</span>;
      case 'pago':
        return <span className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-cyan-950/80 text-cyan-400 border border-cyan-800/80">Pago</span>;
      case 'pendente':
        return <span className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-amber-950/80 text-amber-400 border border-amber-800/80">Pendente</span>;
      case 'cancelado':
        return <span className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-red-950/80 text-red-400 border border-red-800/80">Cancelado</span>;
    }
  };

  // WhatsApp Order Notify
  const handleSendStatusWhatsApp = (order: OrderConfirmationData) => {
    let statusMsg = '';
    if (order.status === 'pago') statusMsg = 'Seu pagamento foi confirmado com sucesso e seu pedido já está sendo preparado!';
    else if (order.status === 'separando') statusMsg = 'Suas peças estão sendo conferidas e embaladas pela equipe ZNK!';
    else if (order.status === 'saiu_para_entrega') statusMsg = 'Seu pedido acabou de sair para entrega com o motoboy em Rio Branco!';
    else if (order.status === 'entregue') statusMsg = 'Consta que seu pedido foi entregue! Esperamos que curta o estilo da ZNK!';
    else statusMsg = `Estamos aguardando a confirmação do seu pedido no valor de ${formatCurrency(order.total)}.`;

    const text = `Fala ${order.customer.fullName.split(' ')[0]}! Aqui é da equipe da *ZNK STORE01*.\n\n` +
      `Atualização do seu Pedido *#${order.orderId}*:\n` +
      `📦 *Status:* ${order.status.toUpperCase()}\n` +
      `💬 ${statusMsg}\n\n` +
      `Qualquer dúvida estamos à disposição!`;

    const cleanNum = order.customer.whatsapp.replace(/\D/g, '');
    window.open(`https://wa.me/55${cleanNum.length === 11 ? cleanNum : '68' + cleanNum}?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#07080B] text-zinc-100 flex flex-col font-sans">
      
      {/* Top Admin Navbar */}
      <header className="sticky top-0 z-30 bg-[#090A0F] border-b border-zinc-800 px-4 sm:px-6 py-3.5 flex items-center justify-between shadow-2xl">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-black border border-[#0066FF] flex items-center justify-center font-bold text-white text-base box-glow-blue-subtle">
            Z
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-heading font-black text-lg sm:text-xl tracking-tight text-white uppercase">
                ZNK <span className="text-[#0066FF]">PAINEL ADM</span>
              </span>
              <span className="px-2 py-0.5 text-[9px] font-mono font-bold bg-[#0066FF]/20 text-[#3385ff] border border-[#0066FF]/40 rounded uppercase">
                LOJISTA
              </span>
            </div>
            <p className="text-[10px] text-zinc-400 font-mono -mt-0.5">
              Gestão de Pedidos, Lucros & Estoque · Rio Branco - AC
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          {isAuthenticated && (
            <button
              type="button"
              onClick={logout}
              className="text-xs text-zinc-400 hover:text-white px-3 py-1.5 rounded-lg border border-zinc-800 hover:bg-zinc-800 transition-colors"
            >
              Bloquear
            </button>
          )}

          <button
            type="button"
            onClick={() => setIsAdminOpen(false)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-[#0066FF] hover:bg-[#0055e6] text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-md"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Ver Loja Virtual</span>
          </button>
        </div>
      </header>

      {/* Main Content */}
      {!isAuthenticated ? (
        /* LOGIN SCREEN */
        <div className="flex-1 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-zinc-950 border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl text-center space-y-6">
            <div className="w-16 h-16 rounded-2xl bg-[#0066FF]/15 border border-[#0066FF]/40 flex items-center justify-center mx-auto text-[#0066FF] box-glow-blue">
              <Lock className="w-8 h-8" />
            </div>

            <div>
              <h2 className="text-xl sm:text-2xl font-black text-white font-heading uppercase">
                ACESSO RESTRITO
              </h2>
              <p className="text-xs text-zinc-400 mt-1 max-w-xs mx-auto">
                Digite a senha do administrador para visualizar pedidos, lucros e estoque da ZNK STORE01.
              </p>
            </div>

            <form onSubmit={handleLoginSubmit} className="space-y-4 text-left">
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1">
                  Senha do Administrador:
                </label>
                <input
                  type="password"
                  autoFocus
                  value={passwordInput}
                  onChange={(e) => {
                    setPasswordInput(e.target.value);
                    setLoginError(false);
                  }}
                  placeholder="Digite 'znk01' ou '1234'"
                  className="w-full bg-zinc-900 border border-zinc-800 focus:border-[#0066FF] text-white text-sm rounded-xl px-4 py-3 focus:outline-none"
                />
                {loginError && (
                  <p className="text-xs text-red-400 mt-1.5">
                    Senha incorreta. Dica: use <strong>znk01</strong> ou clique no botão abaixo.
                  </p>
                )}
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-[#0066FF] hover:bg-[#0055e6] text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all box-glow-blue"
              >
                Entrar no Painel
              </button>
            </form>

            <div className="pt-2 border-t border-zinc-900">
              <button
                type="button"
                onClick={handleQuickLogin}
                className="w-full py-2.5 bg-zinc-900 hover:bg-zinc-850 text-emerald-400 border border-emerald-900/60 font-semibold text-xs rounded-xl transition-colors"
              >
                ⚡ Acesso Rápido com 1-Clique (Modo Demonstração)
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* AUTHENTICATED ADMIN DASHBOARD */
        <div className="flex-1 flex flex-col max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
          
          {/* Navigation Tabs Bar */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-zinc-800 scrollbar-none">
            <button
              type="button"
              onClick={() => setActiveTab('dashboard')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 ${
                activeTab === 'dashboard'
                  ? 'bg-[#0066FF] text-white shadow-lg shadow-[#0066FF]/20'
                  : 'bg-zinc-900/80 text-zinc-400 hover:text-white hover:bg-zinc-850'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              <span>Visão Geral & Lucros</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('orders')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 relative ${
                activeTab === 'orders'
                  ? 'bg-[#0066FF] text-white shadow-lg shadow-[#0066FF]/20'
                  : 'bg-zinc-900/80 text-zinc-400 hover:text-white hover:bg-zinc-850'
              }`}
            >
              <Package className="w-4 h-4" />
              <span>Pedidos ({orders.length})</span>
              {analytics.pendingCount > 0 && (
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
              )}
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('inventory')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 ${
                activeTab === 'inventory'
                  ? 'bg-[#0066FF] text-white shadow-lg shadow-[#0066FF]/20'
                  : 'bg-zinc-900/80 text-zinc-400 hover:text-white hover:bg-zinc-850'
              }`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Estoque & Produtos ({inventory.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('finance')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 ${
                activeTab === 'finance'
                  ? 'bg-[#0066FF] text-white shadow-lg shadow-[#0066FF]/20'
                  : 'bg-zinc-900/80 text-zinc-400 hover:text-white hover:bg-zinc-850'
              }`}
            >
              <DollarSign className="w-4 h-4" />
              <span>Relatório Financeiro</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('logs')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 ${
                activeTab === 'logs'
                  ? 'bg-[#0066FF] text-white shadow-lg shadow-[#0066FF]/20'
                  : 'bg-zinc-900/80 text-zinc-400 hover:text-white hover:bg-zinc-850'
              }`}
            >
              <Activity className="w-4 h-4" />
              <span>Feed de Atividades</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('settings')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 ${
                activeTab === 'settings'
                  ? 'bg-[#0066FF] text-white shadow-lg shadow-[#0066FF]/20'
                  : 'bg-zinc-900/80 text-zinc-400 hover:text-white hover:bg-zinc-850'
              }`}
            >
              <Settings className="w-4 h-4" />
              <span>Configurações</span>
            </button>
          </div>

          {/* TAB 1: DASHBOARD & LUCROS */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              
              {/* Key Metric KPI Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5">
                
                {/* 1. Faturamento Total */}
                <div className="p-4 sm:p-5 rounded-2xl bg-zinc-950 border border-zinc-800 hover:border-[#0066FF] transition-all">
                  <div className="flex items-center justify-between text-zinc-400 mb-2">
                    <span className="text-xs font-mono uppercase">Faturamento Bruto</span>
                    <div className="w-8 h-8 rounded-lg bg-emerald-950/60 border border-emerald-800/80 flex items-center justify-center text-emerald-400">
                      <DollarSign className="w-4 h-4" />
                    </div>
                  </div>
                  <h3 className="text-xl sm:text-3xl font-black text-white font-mono">
                    {formatCurrency(analytics.totalRevenue)}
                  </h3>
                  <p className="text-[11px] text-emerald-400 font-medium mt-1 flex items-center gap-1">
                    <TrendingUp className="w-3.5 h-3.5 inline" />
                    <span>Total recebido em vendas</span>
                  </p>
                </div>

                {/* 2. Lucro Líquido Real */}
                <div className="p-4 sm:p-5 rounded-2xl bg-zinc-950 border border-zinc-800 hover:border-[#0066FF] transition-all box-glow-blue-subtle">
                  <div className="flex items-center justify-between text-zinc-400 mb-2">
                    <span className="text-xs font-mono uppercase text-[#3385ff] font-bold">LUCRO LÍQUIDO REAL</span>
                    <div className="w-8 h-8 rounded-lg bg-[#0066FF]/20 border border-[#0066FF]/60 flex items-center justify-center text-[#3385ff]">
                      <TrendingUp className="w-4 h-4" />
                    </div>
                  </div>
                  <h3 className="text-xl sm:text-3xl font-black text-[#0066FF] font-mono">
                    {formatCurrency(analytics.totalProfit)}
                  </h3>
                  <p className="text-[11px] text-zinc-300 font-medium mt-1">
                    Margem líquida média: <strong className="text-emerald-400">{analytics.profitMarginPercent.toFixed(1)}%</strong>
                  </p>
                </div>

                {/* 3. Pedidos & Ticket Médio */}
                <div className="p-4 sm:p-5 rounded-2xl bg-zinc-950 border border-zinc-800 hover:border-[#0066FF] transition-all">
                  <div className="flex items-center justify-between text-zinc-400 mb-2">
                    <span className="text-xs font-mono uppercase">Total de Pedidos</span>
                    <div className="w-8 h-8 rounded-lg bg-blue-950/60 border border-blue-800/80 flex items-center justify-center text-blue-400">
                      <Package className="w-4 h-4" />
                    </div>
                  </div>
                  <h3 className="text-xl sm:text-3xl font-black text-white font-mono">
                    {analytics.totalOrdersCount}
                  </h3>
                  <p className="text-[11px] text-zinc-400 mt-1">
                    Ticket médio: <strong className="text-white">{formatCurrency(analytics.averageTicket)}</strong>
                  </p>
                </div>

                {/* 4. Peças Vendidas */}
                <div className="p-4 sm:p-5 rounded-2xl bg-zinc-950 border border-zinc-800 hover:border-[#0066FF] transition-all">
                  <div className="flex items-center justify-between text-zinc-400 mb-2">
                    <span className="text-xs font-mono uppercase">Peças Vendidas</span>
                    <div className="w-8 h-8 rounded-lg bg-purple-950/60 border border-purple-800/80 flex items-center justify-center text-purple-400">
                      <ShoppingBag className="w-4 h-4" />
                    </div>
                  </div>
                  <h3 className="text-xl sm:text-3xl font-black text-white font-mono">
                    {analytics.totalItemsSold} un.
                  </h3>
                  <p className="text-[11px] text-zinc-400 mt-1">
                    Itens despachados no estoque
                  </p>
                </div>

              </div>

              {/* Middle Row: Orders Pipeline & Payment breakdown */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* Pipeline de Pedidos em Rio Branco */}
                <div className="lg:col-span-7 p-5 sm:p-6 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-bold text-white font-heading uppercase flex items-center gap-2">
                      <Truck className="w-4 h-4 text-[#0066FF]" />
                      <span>Status dos Pedidos em Tempo Real</span>
                    </h4>
                    <button
                      type="button"
                      onClick={() => setActiveTab('orders')}
                      className="text-xs text-[#0066FF] hover:underline"
                    >
                      Ver lista completa →
                    </button>
                  </div>

                  <div className="grid grid-cols-3 gap-3 pt-2">
                    <div className="p-3.5 rounded-xl bg-zinc-900 border border-zinc-800 text-center">
                      <Clock className="w-4 h-4 text-amber-400 mx-auto mb-1" />
                      <p className="text-xs text-zinc-400">Pendentes / Pagos</p>
                      <p className="text-lg font-black font-mono text-white mt-0.5">{analytics.pendingCount}</p>
                    </div>

                    <div className="p-3.5 rounded-xl bg-zinc-900 border border-zinc-800 text-center">
                      <Truck className="w-4 h-4 text-[#0066FF] mx-auto mb-1" />
                      <p className="text-xs text-zinc-400">Em Rota / Separação</p>
                      <p className="text-lg font-black font-mono text-white mt-0.5">{analytics.inTransitCount}</p>
                    </div>

                    <div className="p-3.5 rounded-xl bg-zinc-900 border border-zinc-800 text-center">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mx-auto mb-1" />
                      <p className="text-xs text-zinc-400">Entregues</p>
                      <p className="text-lg font-black font-mono text-white mt-0.5">{analytics.deliveredCount}</p>
                    </div>
                  </div>

                  {/* Recent Order Preview */}
                  <div className="pt-2">
                    <p className="text-xs font-mono uppercase text-zinc-500 mb-2">Últimos pedidos registrados:</p>
                    <div className="space-y-2">
                      {orders.slice(0, 3).map((ord) => (
                        <div
                          key={ord.orderId}
                          onClick={() => {
                            setSelectedOrderDetails(ord);
                            setActiveTab('orders');
                          }}
                          className="p-3 rounded-xl bg-zinc-900/70 border border-zinc-800/80 hover:border-[#0066FF] flex items-center justify-between cursor-pointer transition-colors text-xs"
                        >
                          <div>
                            <span className="font-mono font-bold text-white">#{ord.orderId}</span>
                            <span className="text-zinc-500 mx-1.5">·</span>
                            <span className="text-zinc-300 font-medium">{ord.customer.fullName}</span>
                            <span className="text-zinc-500 mx-1.5">·</span>
                            <span className="text-zinc-400">{ord.customer.neighborhood}</span>
                          </div>

                          <div className="flex items-center gap-3">
                            <span className="font-mono font-bold text-white">{formatCurrency(ord.total)}</span>
                            {getStatusBadge(ord.status)}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Formas de Pagamento & Economia PIX */}
                <div className="lg:col-span-5 p-5 sm:p-6 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-4">
                  <h4 className="text-sm font-bold text-white font-heading uppercase flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-[#0066FF]" />
                    <span>Divisão de Pagamentos</span>
                  </h4>

                  <div className="space-y-3">
                    {/* PIX */}
                    <div className="p-3.5 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <QrCode className="w-5 h-5 text-emerald-400" />
                        <div>
                          <p className="text-xs font-bold text-white">PIX (5% OFF)</p>
                          <p className="text-[11px] text-zinc-400">{analytics.paymentBreakdown.pixCount} pedidos</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-mono font-bold text-emerald-400">{formatCurrency(analytics.paymentBreakdown.pixTotal)}</p>
                        <p className="text-[10px] text-zinc-500">Taxa 0%</p>
                      </div>
                    </div>

                    {/* Cartão de Crédito */}
                    <div className="p-3.5 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <CreditCard className="w-5 h-5 text-[#3385ff]" />
                        <div>
                          <p className="text-xs font-bold text-white">Cartão de Crédito</p>
                          <p className="text-[11px] text-zinc-400">{analytics.paymentBreakdown.cardCount} pedidos</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-mono font-bold text-white">{formatCurrency(analytics.paymentBreakdown.cardTotal)}</p>
                        <p className="text-[10px] text-zinc-500">Parcelado sem juros</p>
                      </div>
                    </div>

                    {/* Dinheiro */}
                    <div className="p-3.5 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Banknote className="w-5 h-5 text-amber-400" />
                        <div>
                          <p className="text-xs font-bold text-white">Dinheiro na Entrega</p>
                          <p className="text-[11px] text-zinc-400">{analytics.paymentBreakdown.cashCount} pedidos</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-mono font-bold text-white">{formatCurrency(analytics.paymentBreakdown.cashTotal)}</p>
                        <p className="text-[10px] text-zinc-500">Recebimento com motoboy</p>
                      </div>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/60 text-xs text-emerald-300 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                    <span>O PIX representa mais de 65% do volume financeiro, reduzindo taxas de maquininha a zero!</span>
                  </div>
                </div>

              </div>

              {/* Bottom Row: Top Selling Products */}
              <div className="p-5 sm:p-6 rounded-2xl bg-zinc-950 border border-zinc-800">
                <h4 className="text-sm font-bold text-white font-heading uppercase mb-4 flex items-center justify-between">
                  <span>Peças Mais Vendidas & Faturamento</span>
                  <span className="text-xs font-mono text-zinc-400">RANKING DO ESTOQUE</span>
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {analytics.topSellingProducts.slice(0, 3).map((item, idx) => (
                    <div key={idx} className="p-4 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-between">
                      <div className="min-w-0 pr-2">
                        <span className="text-[10px] font-mono text-[#0066FF] font-bold">#{idx + 1} MAIS VENDIDO</span>
                        <h5 className="text-xs font-bold text-white truncate font-heading">{item.name}</h5>
                        <p className="text-xs text-zinc-400 font-mono mt-0.5">{item.quantity} unidades vendidas</p>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="text-sm font-mono font-black text-white">{formatCurrency(item.revenue)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: GESTÃO DE PEDIDOS */}
          {activeTab === 'orders' && (
            <div className="space-y-6">
              
              {/* Filter and Search Bar */}
              <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
                <div className="relative flex-1 max-w-md">
                  <input
                    type="text"
                    value={orderSearch}
                    onChange={(e) => setOrderSearch(e.target.value)}
                    placeholder="Buscar por cliente, pedido #ZNK, bairro..."
                    className="w-full bg-zinc-900 border border-zinc-800 focus:border-[#0066FF] text-white text-xs sm:text-sm rounded-xl px-4 py-2.5 pl-10 focus:outline-none"
                  />
                  <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-3" />
                  {orderSearch && (
                    <button type="button" onClick={() => setOrderSearch('')} className="absolute right-3 top-3 text-zinc-400 hover:text-white">
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Status filter tabs */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                  {(['todos', 'pendente', 'pago', 'separando', 'saiu_para_entrega', 'entregue', 'cancelado'] as const).map((st) => (
                    <button
                      key={st}
                      type="button"
                      onClick={() => setStatusFilter(st)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                        statusFilter === st
                          ? 'bg-[#0066FF] text-white'
                          : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
                      }`}
                    >
                      {st === 'todos' ? 'Todos' : st.replace('_', ' ')}
                    </button>
                  ))}
                </div>
              </div>

              {/* Orders Table */}
              <div className="rounded-2xl bg-zinc-950 border border-zinc-800 overflow-hidden shadow-xl">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-zinc-900 text-zinc-400 border-b border-zinc-800 uppercase font-mono">
                      <tr>
                        <th className="p-4">Pedido / Data</th>
                        <th className="p-4">Cliente</th>
                        <th className="p-4">Endereço (Rio Branco)</th>
                        <th className="p-4">Itens</th>
                        <th className="p-4">Total / Pagamento</th>
                        <th className="p-4">Lucro</th>
                        <th className="p-4">Status</th>
                        <th className="p-4 text-right">Ações</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-800/70">
                      {filteredOrders.length > 0 ? (
                        filteredOrders.map((ord) => (
                          <tr key={ord.orderId} className="hover:bg-zinc-900/40 transition-colors">
                            <td className="p-4">
                              <span className="font-mono font-black text-white text-sm">#{ord.orderId}</span>
                              <p className="text-[10px] text-zinc-500 font-mono mt-0.5">{ord.createdAt}</p>
                            </td>

                            <td className="p-4">
                              <p className="font-bold text-white">{ord.customer.fullName}</p>
                              <p className="text-[11px] text-zinc-400 font-mono">{ord.customer.whatsapp}</p>
                            </td>

                            <td className="p-4">
                              <p className="text-zinc-200 font-medium">{ord.customer.neighborhood}</p>
                              <p className="text-[11px] text-zinc-500 truncate max-w-[180px]">{ord.customer.street}, {ord.customer.number}</p>
                            </td>

                            <td className="p-4">
                              <span className="px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-zinc-300 font-mono">
                                {ord.items.reduce((s, i) => s + i.quantity, 0)} peças
                              </span>
                            </td>

                            <td className="p-4">
                              <p className="font-mono font-bold text-white text-sm">{formatCurrency(ord.total)}</p>
                              <span className="text-[10px] font-mono text-zinc-400 uppercase">
                                {ord.customer.paymentMethod}
                              </span>
                            </td>

                            <td className="p-4">
                              <span className="font-mono font-bold text-emerald-400">
                                {formatCurrency(ord.profit || ord.total * 0.55)}
                              </span>
                            </td>

                            <td className="p-4">
                              <div className="relative inline-block">
                                <select
                                  value={ord.status}
                                  onChange={(e) => updateOrderStatus(ord.orderId, e.target.value as OrderStatus)}
                                  className="bg-zinc-900 border border-zinc-700 text-xs text-white rounded-lg px-2.5 py-1 focus:outline-none cursor-pointer"
                                >
                                  <option value="pendente">Pendente</option>
                                  <option value="pago">Pago</option>
                                  <option value="separando">Separando</option>
                                  <option value="saiu_para_entrega">Saiu p/ Entrega</option>
                                  <option value="entregue">Entregue</option>
                                  <option value="cancelado">Cancelado</option>
                                </select>
                              </div>
                            </td>

                            <td className="p-4 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => setSelectedOrderDetails(ord)}
                                  className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800"
                                  title="Ver Detalhes do Pedido"
                                >
                                  <Eye className="w-4 h-4 text-[#0066FF]" />
                                </button>

                                <button
                                  type="button"
                                  onClick={() => handleSendStatusWhatsApp(ord)}
                                  className="p-1.5 text-zinc-400 hover:text-emerald-400 rounded-lg hover:bg-zinc-800"
                                  title="Notificar no WhatsApp"
                                >
                                  <MessageCircle className="w-4 h-4 text-emerald-500" />
                                </button>

                                <button
                                  type="button"
                                  onClick={() => {
                                    if (confirm(`Deseja realmente remover o pedido #${ord.orderId}?`)) {
                                      deleteOrder(ord.orderId);
                                    }
                                  }}
                                  className="p-1.5 text-zinc-500 hover:text-red-400 rounded-lg hover:bg-zinc-800"
                                  title="Excluir Pedido"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={8} className="p-12 text-center text-zinc-500">
                            Nenhum pedido encontrado com os filtros selecionados.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* TAB 3: ESTOQUE & PRODUTOS */}
          {activeTab === 'inventory' && (
            <div className="space-y-6">
              
              <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="relative flex-1 max-w-md w-full">
                  <input
                    type="text"
                    value={inventorySearch}
                    onChange={(e) => setInventorySearch(e.target.value)}
                    placeholder="Buscar peça no estoque..."
                    className="w-full bg-zinc-900 border border-zinc-800 focus:border-[#0066FF] text-white text-xs sm:text-sm rounded-xl px-4 py-2.5 pl-10 focus:outline-none"
                  />
                  <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-3" />
                </div>

                <div className="text-xs text-zinc-400">
                  Total de peças cadastradas: <strong className="text-white">{inventory.length} modelos</strong>
                </div>
              </div>

              {/* Inventory Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredInventory.map((item) => {
                  const profitPerUnit = item.price - item.costPrice;
                  const unitMargin = (profitPerUnit / item.price) * 100;

                  return (
                    <div
                      key={item.id}
                      className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 hover:border-[#0066FF] transition-all flex flex-col justify-between space-y-4"
                    >
                      <div className="flex gap-3">
                        <img
                          src={item.images[0]}
                          alt={item.name}
                          className="w-20 h-20 rounded-xl object-cover border border-zinc-800 shrink-0"
                        />
                        <div className="min-w-0 flex-1">
                          <span className="text-[10px] font-mono text-[#0066FF] uppercase font-bold">
                            {item.category}
                          </span>
                          <h4 className="text-xs sm:text-sm font-bold text-white font-heading truncate">
                            {item.name}
                          </h4>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-sm font-mono font-black text-white">
                              {formatCurrency(item.price)}
                            </span>
                            <span className="text-[11px] font-mono text-zinc-500">
                              (Custo: {formatCurrency(item.costPrice)})
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Stock controller */}
                      <div className="p-3 rounded-xl bg-zinc-900/80 border border-zinc-800 text-xs space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-zinc-400 font-mono">Estoque em Rio Branco:</span>
                          <span className={`font-mono font-bold ${item.stock <= 5 ? 'text-amber-400' : 'text-white'}`}>
                            {item.stock} unidades
                          </span>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="text-zinc-400 font-mono">Lucro Líquido / Peça:</span>
                          <span className="font-mono font-bold text-emerald-400">
                            +{formatCurrency(profitPerUnit)} ({unitMargin.toFixed(0)}%)
                          </span>
                        </div>

                        {/* Quick stock +/- adjuster */}
                        <div className="flex items-center justify-between pt-1 border-t border-zinc-800">
                          <span className="text-[11px] text-zinc-400">Ajuste rápido:</span>
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => updateProductStock(item.id, Math.max(0, item.stock - 1))}
                              className="px-2 py-0.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded text-xs"
                            >
                              -1
                            </button>
                            <button
                              type="button"
                              onClick={() => updateProductStock(item.id, item.stock + 1)}
                              className="px-2 py-0.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded text-xs"
                            >
                              +1
                            </button>
                            <button
                              type="button"
                              onClick={() => updateProductStock(item.id, item.stock + 5)}
                              className="px-2 py-0.5 bg-[#0066FF] hover:bg-[#0055e6] text-white rounded text-xs font-bold"
                            >
                              +5
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Edit Modal Button */}
                      <button
                        type="button"
                        onClick={() => setEditingProduct(item)}
                        className="w-full py-2 bg-zinc-900 hover:bg-zinc-850 text-zinc-200 border border-zinc-800 hover:border-[#0066FF] rounded-xl text-xs font-semibold transition-colors"
                      >
                        Editar Preço e Custo
                      </button>
                    </div>
                  );
                })}
              </div>

            </div>
          )}

          {/* TAB 4: RELATÓRIO FINANCEIRO & DETALHES DE LUCRO */}
          {activeTab === 'finance' && (
            <div className="space-y-6">
              
              <div className="p-6 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-6">
                <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
                  <div>
                    <h3 className="text-lg font-bold text-white font-heading uppercase">
                      Demonstrativo de Resultado do Exercício (DRE)
                    </h3>
                    <p className="text-xs text-zinc-400 font-mono">
                      Apuração financeira real da loja ZNK STORE01
                    </p>
                  </div>
                  <span className="px-3 py-1 bg-emerald-950/80 text-emerald-400 border border-emerald-800/80 rounded-full text-xs font-mono font-bold">
                    SAUDÁVEL (ALTA MARGEM)
                  </span>
                </div>

                <div className="space-y-3 font-mono text-sm">
                  <div className="flex justify-between p-3 rounded-xl bg-zinc-900 border border-zinc-800">
                    <span className="text-white font-bold">(+) Faturamento Bruto (Receita Total)</span>
                    <span className="font-bold text-white">{formatCurrency(analytics.totalRevenue)}</span>
                  </div>

                  <div className="flex justify-between p-3 rounded-xl bg-zinc-900/60 border border-zinc-850 text-zinc-300">
                    <span>(-) Custo das Peças / Mercadorias Vendidas (CPV)</span>
                    <span className="text-red-400">-{formatCurrency(analytics.totalRevenue - analytics.totalProfit)}</span>
                  </div>

                  <div className="flex justify-between p-3 rounded-xl bg-zinc-900/60 border border-zinc-850 text-zinc-300">
                    <span>(-) Descontos Concedidos no PIX (5%)</span>
                    <span className="text-amber-400">-{formatCurrency(orders.reduce((s, o) => s + (o.discount || 0), 0))}</span>
                  </div>

                  <div className="flex justify-between p-4 rounded-xl bg-[#0066FF]/15 border border-[#0066FF]/60 text-white text-base font-black">
                    <span className="text-[#3385ff]">(=) LUCRO LÍQUIDO REAL DA OPERAÇÃO</span>
                    <span className="text-[#3385ff] text-xl">{formatCurrency(analytics.totalProfit)}</span>
                  </div>
                </div>

                {/* Insight cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-zinc-800">
                  <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
                    <p className="text-xs text-zinc-400 font-mono">Margem de Lucro Médio</p>
                    <p className="text-2xl font-black font-mono text-emerald-400 mt-1">
                      {analytics.profitMarginPercent.toFixed(1)}%
                    </p>
                    <p className="text-[11px] text-zinc-500 mt-1">Acima da média do setor (45%)</p>
                  </div>

                  <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
                    <p className="text-xs text-zinc-400 font-mono">Lucro por Pedido Realizado</p>
                    <p className="text-2xl font-black font-mono text-white mt-1">
                      {formatCurrency(analytics.totalProfit / Math.max(1, analytics.totalOrdersCount))}
                    </p>
                    <p className="text-[11px] text-zinc-500 mt-1">Média limpa no bolso por entrega</p>
                  </div>

                  <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
                    <p className="text-xs text-zinc-400 font-mono">Taxas de Cartão Economizadas</p>
                    <p className="text-2xl font-black font-mono text-cyan-400 mt-1">
                      {formatCurrency(analytics.paymentBreakdown.pixTotal * 0.04)}
                    </p>
                    <p className="text-[11px] text-zinc-500 mt-1">Economizado incentivando o PIX</p>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* TAB 5: FEED DE ATIVIDADES EM TEMPO REAL */}
          {activeTab === 'logs' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-bold text-white font-heading uppercase flex items-center gap-2">
                  <Activity className="w-4 h-4 text-[#0066FF]" />
                  <span>Histórico de Atividades & Ações da Loja</span>
                </h4>
                <span className="text-xs font-mono text-zinc-400">{logs.length} eventos registrados</span>
              </div>

              <div className="space-y-2.5">
                {logs.map((lg) => (
                  <div
                    key={lg.id}
                    className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 flex items-start justify-between gap-4"
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-lg bg-zinc-900 border border-zinc-700 flex items-center justify-center text-[#3385ff] shrink-0 mt-0.5">
                        <Activity className="w-4 h-4" />
                      </div>
                      <div>
                        <h5 className="text-xs font-bold text-white font-heading">{lg.action}</h5>
                        <p className="text-xs text-zinc-400 mt-0.5 leading-relaxed">{lg.details}</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-zinc-500 whitespace-nowrap">{lg.timestamp}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: CONFIGURAÇÕES DA LOJA */}
          {activeTab === 'settings' && (
            <div className="p-6 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-6 max-w-2xl">
              <div>
                <h4 className="text-base font-bold text-white font-heading uppercase">
                  Parâmetros Comerciais ZNK STORE01
                </h4>
                <p className="text-xs text-zinc-400 mt-1">
                  Valores que regem os cálculos de frete e canais de atendimento em Rio Branco.
                </p>
              </div>

              <div className="space-y-4 text-xs">
                <div>
                  <label className="block text-zinc-400 font-medium mb-1">WhatsApp da Loja:</label>
                  <input
                    type="text"
                    readOnly
                    value={STORE_CONFIG.whatsappDisplay}
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl p-3 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-zinc-400 font-medium mb-1">Chave PIX Oficial:</label>
                  <input
                    type="text"
                    readOnly
                    value={STORE_CONFIG.pixKey}
                    className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl p-3 font-mono"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-zinc-400 font-medium mb-1">Meta Frete Grátis:</label>
                    <input
                      type="text"
                      readOnly
                      value={formatCurrency(STORE_CONFIG.freeShippingThreshold)}
                      className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl p-3 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-zinc-400 font-medium mb-1">Frete Local (Rio Branco):</label>
                    <input
                      type="text"
                      readOnly
                      value={formatCurrency(STORE_CONFIG.localShippingRate)}
                      className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl p-3 font-mono"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-zinc-900 flex justify-between items-center">
                <button
                  type="button"
                  onClick={resetDataToDefaults}
                  className="px-4 py-2.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-800 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Restaurar Dados Padrão</span>
                </button>

                <button
                  type="button"
                  onClick={() => alert('Configurações salvas com sucesso!')}
                  className="px-5 py-2.5 bg-[#0066FF] hover:bg-[#0055e6] text-white rounded-xl text-xs font-bold uppercase transition-colors"
                >
                  Salvar Alterações
                </button>
              </div>
            </div>
          )}

        </div>
      )}

      {/* MODAL: DETALHES DO PEDIDO SELECIONADO */}
      {selectedOrderDetails && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
          <div
            className="relative w-full max-w-2xl bg-[#090A0F] border border-zinc-800 rounded-3xl p-6 shadow-2xl text-zinc-100 max-h-[90vh] overflow-y-auto space-y-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
              <div>
                <span className="font-mono font-black text-xl text-white">Pedido #{selectedOrderDetails.orderId}</span>
                <p className="text-xs text-zinc-400 font-mono">Registrado em {selectedOrderDetails.createdAt}</p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedOrderDetails(null)}
                className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Status Bar */}
            <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-between">
              <div>
                <span className="text-xs text-zinc-400">Status atual:</span>
                <div className="mt-1">{getStatusBadge(selectedOrderDetails.status)}</div>
              </div>

              <div className="flex items-center gap-2">
                <select
                  value={selectedOrderDetails.status}
                  onChange={(e) => {
                    const newSt = e.target.value as OrderStatus;
                    updateOrderStatus(selectedOrderDetails.orderId, newSt);
                    setSelectedOrderDetails({ ...selectedOrderDetails, status: newSt });
                  }}
                  className="bg-zinc-900 border border-zinc-700 text-xs text-white rounded-xl px-3 py-2 cursor-pointer focus:outline-none"
                >
                  <option value="pendente">Pendente</option>
                  <option value="pago">Pago</option>
                  <option value="separando">Separando no Estoque</option>
                  <option value="saiu_para_entrega">Saiu para Entrega</option>
                  <option value="entregue">Entregue / Concluído</option>
                  <option value="cancelado">Cancelado</option>
                </select>

                <button
                  type="button"
                  onClick={() => handleSendStatusWhatsApp(selectedOrderDetails)}
                  className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>Chamar</span>
                </button>
              </div>
            </div>

            {/* Customer Details */}
            <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 text-xs space-y-2">
              <h5 className="font-bold uppercase text-white font-heading">Dados do Cliente:</h5>
              <p><strong>Nome:</strong> {selectedOrderDetails.customer.fullName}</p>
              <p><strong>WhatsApp:</strong> {selectedOrderDetails.customer.whatsapp}</p>
              <p><strong>Endereço de Entrega:</strong> {selectedOrderDetails.customer.street}, {selectedOrderDetails.customer.number} {selectedOrderDetails.customer.complement ? `(${selectedOrderDetails.customer.complement})` : ''}</p>
              <p><strong>Bairro / Cidade:</strong> {selectedOrderDetails.customer.neighborhood}, {selectedOrderDetails.customer.city} - {selectedOrderDetails.customer.state}</p>
              {selectedOrderDetails.customer.notes && (
                <p className="text-amber-300"><strong>Observação do cliente:</strong> "{selectedOrderDetails.customer.notes}"</p>
              )}
            </div>

            {/* Items List */}
            <div className="space-y-2">
              <h5 className="text-xs font-bold uppercase text-white font-heading">Peças Solicitadas:</h5>
              <div className="space-y-2">
                {selectedOrderDetails.items.map((it, idx) => (
                  <div key={idx} className="p-3 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center gap-3">
                    <img src={it.product.images[0]} alt={it.product.name} className="w-12 h-12 rounded-lg object-cover" />
                    <div className="flex-1 min-w-0 text-xs">
                      <p className="font-bold text-white truncate">{it.product.name}</p>
                      <p className="text-zinc-400 font-mono">Tamanho: <strong className="text-white">{it.size}</strong> · Quantidade: {it.quantity}</p>
                    </div>
                    <span className="font-mono font-bold text-white text-xs">{formatCurrency(it.product.price * it.quantity)}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Financial Summary */}
            <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 text-xs space-y-1.5 font-mono">
              <div className="flex justify-between text-zinc-400">
                <span>Subtotal:</span>
                <span>{formatCurrency(selectedOrderDetails.subtotal)}</span>
              </div>
              {selectedOrderDetails.discount > 0 && (
                <div className="flex justify-between text-emerald-400">
                  <span>Desconto Aplicado (PIX 5%):</span>
                  <span>-{formatCurrency(selectedOrderDetails.discount)}</span>
                </div>
              )}
              <div className="flex justify-between text-zinc-400">
                <span>Frete:</span>
                <span>{selectedOrderDetails.shipping === 0 ? 'GRÁTIS' : formatCurrency(selectedOrderDetails.shipping)}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-zinc-800 text-sm font-bold text-white">
                <span>Total Recebido:</span>
                <span className="text-[#0066FF] text-base">{formatCurrency(selectedOrderDetails.total)}</span>
              </div>
              <div className="flex justify-between pt-1 text-emerald-400 font-bold">
                <span>Lucro Líquido Apurado:</span>
                <span>+{formatCurrency(selectedOrderDetails.profit || selectedOrderDetails.total * 0.55)}</span>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setSelectedOrderDetails(null)}
                className="px-5 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl text-xs font-semibold transition-colors"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: EDITAR PREÇO E CUSTO DO PRODUTO */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div
            className="w-full max-w-md bg-zinc-950 border border-zinc-800 rounded-2xl p-6 text-zinc-100 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <h4 className="font-bold text-white font-heading text-sm uppercase">Editar Preços e Margem</h4>
              <button type="button" onClick={() => setEditingProduct(null)} className="text-zinc-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex items-center gap-3">
              <img src={editingProduct.images[0]} alt={editingProduct.name} className="w-14 h-14 rounded-lg object-cover" />
              <div className="min-w-0">
                <p className="text-xs font-bold text-white truncate">{editingProduct.name}</p>
                <p className="text-[11px] text-zinc-400 font-mono">{editingProduct.category}</p>
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-zinc-400 mb-1">Preço de Venda ao Cliente (R$):</label>
                <input
                  type="number"
                  step="0.10"
                  value={editingProduct.price}
                  onChange={(e) => setEditingProduct({ ...editingProduct, price: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl p-2.5 font-mono"
                />
              </div>

              <div>
                <label className="block text-zinc-400 mb-1">Custo de Fabricação / Compra (R$):</label>
                <input
                  type="number"
                  step="0.10"
                  value={editingProduct.costPrice}
                  onChange={(e) => setEditingProduct({ ...editingProduct, costPrice: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl p-2.5 font-mono"
                />
              </div>

              <div className="p-3 bg-zinc-900 rounded-xl text-[11px] text-emerald-400 font-mono">
                Lucro por peça: +{formatCurrency(Math.max(0, editingProduct.price - editingProduct.costPrice))}
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditingProduct(null)}
                className="px-4 py-2 bg-zinc-900 text-zinc-400 hover:text-white rounded-xl text-xs"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  updateProductPrice(editingProduct.id, editingProduct.price, editingProduct.costPrice);
                  setEditingProduct(null);
                }}
                className="px-5 py-2 bg-[#0066FF] hover:bg-[#0055e6] text-white rounded-xl text-xs font-bold"
              >
                Salvar Alterações
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
