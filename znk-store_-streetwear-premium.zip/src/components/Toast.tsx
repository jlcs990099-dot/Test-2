import React from 'react';
import { ShoppingBag } from 'lucide-react';
import { useCart } from '../context/CartContext';

export const Toast: React.FC = () => {
  const { toastMessage, setIsCartOpen } = useCart();

  if (!toastMessage) return null;

  return (
    <div className="fixed bottom-24 sm:bottom-8 left-1/2 -translate-x-1/2 z-50 animate-fade-in pointer-events-auto">
      <div className="bg-[#090A0F] border border-[#0066FF] shadow-2xl shadow-[#0066FF]/25 rounded-2xl px-5 py-3 text-xs sm:text-sm text-white flex items-center gap-3.5 backdrop-blur-md">
        <div className="w-7 h-7 rounded-lg bg-[#0066FF] text-white flex items-center justify-center shrink-0">
          <ShoppingBag className="w-4 h-4" />
        </div>
        <span className="font-medium">{toastMessage}</span>
        <button
          type="button"
          onClick={() => setIsCartOpen(true)}
          className="ml-2 px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-colors shrink-0"
        >
          Ver Carrinho
        </button>
      </div>
    </div>
  );
};
