import React from 'react';
import { Instagram, Heart, MessageCircle, ArrowUpRight } from 'lucide-react';
import { STORE_CONFIG } from '../config/storeConfig';
import { ScrollReveal } from './ScrollReveal';

import fullDropCapsShirtsImg from '../assets/images/znk_full_drop_caps_shirts_1791344001861.jpg';
import conjuntoHighCoImg from '../assets/images/znk_conjunto_highco_1791343982298.jpg';
import conjuntoFlamengoImg from '../assets/images/znk_conjunto_flamengo_1791343991903.jpg';
import chronicBiggieImg from '../assets/images/znk_chronic_biggie_1791343173890.jpg';

export const InstagramSection: React.FC = () => {
  const instagramPosts = [
    {
      id: 'ig-1',
      image: fullDropCapsShirtsImg,
      likes: '920',
      comments: '84',
      caption: 'DROP COMPLETO DISPONÍVEL! 18 modelos de camisetas oversized + bonés 5-Panel Anth Co e Origin sobrepostos. Peça pelo direct ou WhatsApp. #znkstore01 #riobranco #acre #streetwear',
    },
    {
      id: 'ig-2',
      image: conjuntoHighCoImg,
      likes: '685',
      comments: '52',
      caption: 'COMBO DO DIA: Camiseta Nike Skeleton Lady Just Do It + Short Tactel High Co. Black bordado. Look montado com atitude. #highco #nike #streetstyle #znk',
    },
    {
      id: 'ig-3',
      image: conjuntoFlamengoImg,
      likes: '810',
      comments: '67',
      caption: 'LINHA ESPORTIVA: Camisa de Treino Flamengo Off-White e Dourado + Short Bege Adidas + Sandália Slide. Peças no estoque físico! #flamengo #crf #streetwear',
    },
    {
      id: 'ig-4',
      image: chronicBiggieImg,
      likes: '744',
      comments: '61',
      caption: 'Chronic No. 11 Biggie Smalls 420c. Roxo imperial com caimento oversized legítimo. #notoriousbig #chronic #rap #znk01',
    },
  ];

  return (
    <section className="py-16 sm:py-24 border-b border-zinc-800/80 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <ScrollReveal duration={650} distance={28}>
          <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-10 gap-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Instagram className="w-4 h-4 text-[#0066FF]" />
                <span className="text-xs font-mono uppercase tracking-widest text-[#0066FF] font-semibold">
                  FEED OFICIAL @ZNK.STORE01
                </span>
              </div>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white uppercase font-heading tracking-tight">
                SIGA A <span className="text-[#0066FF]">ZNK</span>
              </h2>
              <p className="text-zinc-400 text-sm mt-2 max-w-lg">
                Confira nossos lançamentos, novidades e promoções no Instagram. Fotos reais de cada peça direto da nossa loja em Rio Branco - AC.
              </p>
            </div>

            <div>
              <a
                href={STORE_CONFIG.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3.5 bg-gradient-to-r from-zinc-900 to-zinc-850 hover:from-[#0066FF] hover:to-[#0055e6] text-white font-bold text-xs uppercase tracking-wider rounded-xl border border-zinc-700/80 hover:border-[#0066FF] transition-all shadow-lg group"
              >
                <Instagram className="w-4 h-4 text-[#3385ff] group-hover:text-white transition-colors" />
                <span>{STORE_CONFIG.instagramHandle.toUpperCase()}</span>
                <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </a>
            </div>
          </div>
        </ScrollReveal>

        {/* Instagram Visual Grid with Staggered Fade-in Up */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-5">
          {instagramPosts.map((post, index) => (
            <ScrollReveal
              key={post.id}
              delay={index * 80}
              duration={650}
              distance={28}
            >
              <a
                href={STORE_CONFIG.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative aspect-square rounded-2xl overflow-hidden bg-zinc-900 border border-zinc-800/80 hover:border-[#0066FF] transition-all duration-300 shadow-md block"
              >
                <img
                  src={post.image}
                  alt="Post Instagram ZNK STORE01"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  loading="lazy"
                />

                {/* Hover overlay with likes & comments */}
                <div className="absolute inset-0 bg-black/80 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center p-4 text-center">
                  <div className="flex items-center gap-4 text-white text-xs font-mono font-bold mb-3">
                    <span className="flex items-center gap-1.5">
                      <Heart className="w-4 h-4 fill-red-500 text-red-500" />
                      {post.likes}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <MessageCircle className="w-4 h-4 text-[#3385ff]" />
                      {post.comments}
                    </span>
                  </div>
                  <p className="text-[11px] text-zinc-300 line-clamp-3 leading-relaxed">
                    {post.caption}
                  </p>
                  <span className="mt-3 text-[10px] uppercase font-bold text-[#3385ff] tracking-wider">
                    Ver no Instagram →
                  </span>
                </div>
              </a>
            </ScrollReveal>
          ))}
        </div>

      </div>
    </section>
  );
};
