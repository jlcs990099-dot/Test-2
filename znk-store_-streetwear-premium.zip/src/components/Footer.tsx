import React from 'react';
import { Instagram, Phone, MapPin, Truck, ShieldCheck, ArrowUp, Lock } from 'lucide-react';
import { STORE_CONFIG, generateWhatsAppLink } from '../config/storeConfig';
import { useAdmin } from '../context/AdminContext';
import { ScrollReveal } from './ScrollReveal';

export const Footer: React.FC = () => {
  const { setIsAdminOpen } = useAdmin();
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navLinks = [
    { label: 'Início', href: '#inicio' },
    { label: 'Produtos', href: '#produtos' },
    { label: 'Promoções', href: '#promocoes' },
    { label: 'Sobre nós', href: '#sobre' },
    { label: 'Feedbacks', href: '#feedbacks' },
    { label: 'Contato', href: '#contato' },
  ];

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    if (href === '#contato') {
      window.open(generateWhatsAppLink('Olá ZNK STORE01! Vim pelo site e gostaria de falar com vocês.'), '_blank');
      return;
    }
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer id="contato" className="bg-[#050608] border-t border-zinc-800 text-zinc-400 text-xs pt-16 pb-12">
      <ScrollReveal duration={650} distance={24}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-zinc-900">
          
          {/* Brand Info */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-zinc-900 border border-[#0066FF] flex items-center justify-center font-bold text-white text-base">
                Z
              </div>
              <span className="font-heading font-black text-xl sm:text-2xl tracking-tight text-white uppercase">
                ZNK <span className="text-[#0066FF]">STORE01</span>
              </span>
            </div>

            <p className="text-zinc-300 text-sm italic font-medium">
              "Elegância e estilo em cada detalhe."
            </p>

            <p className="text-zinc-400 text-xs leading-relaxed max-w-sm">
              Loja de roupas masculinas streetwear e oversized, conectando autenticidade, corte premium e conforto para o visual urbano.
            </p>

            <div className="flex flex-col gap-2 pt-2 text-zinc-300">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#0066FF]" />
                <span className="font-semibold text-white">Rio Branco - AC</span>
              </div>
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-[#0066FF]" />
                <span>Enviamos para todo o Brasil 🇧🇷</span>
              </div>
            </div>
          </div>

          {/* Quick Navigation Links */}
          <div className="lg:col-span-3 space-y-3">
            <h3 className="font-heading font-bold text-sm text-white uppercase tracking-wider">
              Navegação
            </h3>
            <ul className="space-y-2 text-xs">
              {navLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    onClick={(e) => handleLinkClick(e, link.href)}
                    className="hover:text-white hover:underline transition-colors block py-0.5"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact and Social Links */}
          <div className="lg:col-span-4 space-y-4">
            <h3 className="font-heading font-bold text-sm text-white uppercase tracking-wider">
              Redes Sociais & Contato
            </h3>
            
            <div className="space-y-3">
              <a
                href={STORE_CONFIG.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-3 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-[#0066FF] text-zinc-300 hover:text-white transition-all group"
              >
                <div className="w-8 h-8 rounded-lg bg-zinc-900 flex items-center justify-center text-[#3385ff] group-hover:bg-[#0066FF] group-hover:text-white transition-colors">
                  <Instagram className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-[11px] text-zinc-500 uppercase font-mono">Instagram Oficial</p>
                  <p className="text-xs font-bold text-white">{STORE_CONFIG.instagramHandle}</p>
                </div>
              </a>

              <a
                href={generateWhatsAppLink('Olá ZNK STORE01! Vim pelo rodapé do site.')}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-3 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-emerald-500 text-zinc-300 hover:text-white transition-all group"
              >
                <div className="w-8 h-8 rounded-lg bg-zinc-900 flex items-center justify-center text-emerald-400 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-[11px] text-zinc-500 uppercase font-mono">WhatsApp Direto</p>
                  <p className="text-xs font-bold text-white">{STORE_CONFIG.whatsappDisplay}</p>
                </div>
              </a>
            </div>

            <div className="pt-2 text-[11px] text-zinc-500">
              <p>Atendimento de Segunda a Sábado: 09h às 19h (Horário do Acre)</p>
            </div>
          </div>

        </div>

        {/* Bottom Bar: Copyright & Payment Badges */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-4 text-center sm:text-left">
            <p className="text-zinc-500 text-[11px]">
              © 2026 ZNK STORE01. Todos os direitos reservados.
            </p>
            <span className="hidden sm:inline text-zinc-700">·</span>
            <button
              type="button"
              onClick={() => setIsAdminOpen(true)}
              className="text-zinc-500 hover:text-[#0066FF] text-[11px] font-mono flex items-center gap-1 transition-colors"
            >
              <Lock className="w-3 h-3 text-[#0066FF]" />
              <span>Painel ADM (Lojista)</span>
            </button>
          </div>

          <div className="flex items-center gap-3 text-[10px] text-zinc-400">
            <span className="px-2 py-1 bg-zinc-950 border border-zinc-800 rounded font-mono font-bold text-white">PIX</span>
            <span className="px-2 py-1 bg-zinc-950 border border-zinc-800 rounded font-mono font-bold text-white">CARTÃO</span>
            <span className="px-2 py-1 bg-zinc-950 border border-zinc-800 rounded font-mono font-bold text-white">DINHEIRO</span>
          </div>

          <button
            type="button"
            onClick={scrollToTop}
            className="p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-white hover:border-[#0066FF] transition-colors"
            aria-label="Voltar ao topo da página"
            title="Voltar ao topo"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>

      </div>
      </ScrollReveal>
    </footer>
  );
};
