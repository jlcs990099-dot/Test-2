import React, { useState, useMemo } from 'react';
import { Search, SlidersHorizontal, X, Sparkles, RefreshCw } from 'lucide-react';
import { PRODUCTS } from '../data/products';
import { Product, ProductCategory } from '../types';
import { ProductCard } from './ProductCard';
import { ScrollReveal } from './ScrollReveal';

interface ProductsSectionProps {
  onViewProduct: (product: Product) => void;
  selectedCategory: ProductCategory;
  setSelectedCategory: (cat: ProductCategory) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
}

export const ProductsSection: React.FC<ProductsSectionProps> = ({
  onViewProduct,
  selectedCategory,
  setSelectedCategory,
  searchQuery,
  setSearchQuery,
}) => {
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'discount'>('featured');
  const [onlyPromo, setOnlyPromo] = useState(false);
  const [priceRange, setPriceRange] = useState<'all' | 'under100' | '100to200' | 'above200'>('all');

  const categoriesList: ProductCategory[] = [
    'Todos',
    'Camisetas',
    'Oversized',
    'Shorts',
    'Conjuntos',
    'Acessórios',
  ];

  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((item) => {
      // Category filter
      if (selectedCategory !== 'Todos' && item.category !== selectedCategory) {
        return false;
      }

      // Promo filter
      if (onlyPromo && !item.isPromo) {
        return false;
      }

      // Price range
      if (priceRange === 'under100' && item.price >= 100) return false;
      if (priceRange === '100to200' && (item.price < 100 || item.price > 200)) return false;
      if (priceRange === 'above200' && item.price <= 200) return false;

      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const matchesName = item.name.toLowerCase().includes(query);
        const matchesCat = item.category.toLowerCase().includes(query);
        const matchesDesc = item.description.toLowerCase().includes(query);
        if (!matchesName && !matchesCat && !matchesDesc) return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'discount') return (b.discountPercent || 0) - (a.discountPercent || 0);
      return (b.isBestSeller ? 1 : 0) - (a.isBestSeller ? 1 : 0);
    });
  }, [selectedCategory, onlyPromo, priceRange, searchQuery, sortBy]);

  const handleResetFilters = () => {
    setSelectedCategory('Todos');
    setSearchQuery('');
    setOnlyPromo(false);
    setPriceRange('all');
    setSortBy('featured');
  };

  return (
    <section id="produtos" className="py-16 sm:py-24 border-b border-zinc-800/80 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with ScrollReveal */}
        <ScrollReveal duration={650} distance={28}>
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 sm:mb-12 gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="w-2.5 h-0.5 bg-[#0066FF]" />
                <span className="text-xs font-mono uppercase tracking-widest text-[#0066FF] font-semibold">
                  CATÁLOGO EXCLUSIVO
                </span>
              </div>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white uppercase font-heading tracking-tight">
                MAIS <span className="text-[#0066FF]">VENDIDOS</span>
              </h2>
            </div>
            <p className="text-zinc-400 text-sm max-w-md">
              As peças mais procuradas do streetwear masculino em Rio Branco. Cortes autênticos, tecidos de alta durabilidade e pronta entrega.
            </p>
          </div>
        </ScrollReveal>

        {/* Filter Controls Bar */}
        <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-4 sm:p-5 mb-8 space-y-4">
          
          {/* Top Row: Search Input & Quick Selectors */}
          <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
            
            {/* Search Input */}
            <div className="relative flex-1 max-w-md">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Buscar por camiseta, short, cargo, cor..."
                className="w-full bg-zinc-900 border border-zinc-800 focus:border-[#0066FF] text-white text-xs sm:text-sm rounded-xl px-4 py-2.5 pl-10 focus:outline-none placeholder:text-zinc-500"
              />
              <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-3" />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-3 text-zinc-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Sort & Promo Options */}
            <div className="flex flex-wrap items-center gap-2 sm:gap-3">
              
              {/* Promo Toggle */}
              <button
                type="button"
                onClick={() => setOnlyPromo(!onlyPromo)}
                className={`px-3 py-2 text-xs font-semibold rounded-xl border transition-colors flex items-center gap-1.5 ${
                  onlyPromo
                    ? 'bg-[#0066FF] text-white border-[#0066FF]'
                    : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Apenas Promoções</span>
              </button>

              {/* Price Sort Dropdown */}
              <div className="flex items-center gap-1.5 bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-1.5">
                <SlidersHorizontal className="w-3.5 h-3.5 text-zinc-400" />
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-transparent text-xs text-zinc-200 focus:outline-none cursor-pointer pr-1"
                >
                  <option value="featured" className="bg-zinc-900 text-white">Destaques</option>
                  <option value="price-asc" className="bg-zinc-900 text-white">Menor Preço</option>
                  <option value="price-desc" className="bg-zinc-900 text-white">Maior Preço</option>
                  <option value="discount" className="bg-zinc-900 text-white">Maior Desconto</option>
                </select>
              </div>

              {/* Price Range Filter */}
              <select
                value={priceRange}
                onChange={(e) => setPriceRange(e.target.value as any)}
                className="bg-zinc-900 border border-zinc-800 text-xs text-zinc-200 rounded-xl px-3 py-2 focus:outline-none cursor-pointer"
              >
                <option value="all" className="bg-zinc-900">Qualquer Valor</option>
                <option value="under100" className="bg-zinc-900">Até R$ 100</option>
                <option value="100to200" className="bg-zinc-900">R$ 100 a R$ 200</option>
                <option value="above200" className="bg-zinc-900">Acima de R$ 200</option>
              </select>

            </div>

          </div>

          {/* Bottom Row: Category Buttons */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none pt-1">
            {categoriesList.map((category) => (
              <button
                key={category}
                type="button"
                onClick={() => setSelectedCategory(category)}
                className={`whitespace-nowrap px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  selectedCategory === category
                    ? 'bg-[#0066FF] text-white shadow-md shadow-[#0066FF]/20'
                    : 'bg-zinc-900/80 text-zinc-400 hover:text-white hover:bg-zinc-800 border border-zinc-800/80'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

        </div>

        {/* Results Counter & Active Filter Tags */}
        <div className="flex items-center justify-between text-xs text-zinc-400 mb-6">
          <p>
            Mostrando <span className="text-white font-bold">{filteredProducts.length}</span> produtos
            {selectedCategory !== 'Todos' && (
              <span> em <strong className="text-[#3385ff]">{selectedCategory}</strong></span>
            )}
            {searchQuery && (
              <span> para "<strong className="text-white">{searchQuery}</strong>"</span>
            )}
          </p>

          {(selectedCategory !== 'Todos' || searchQuery || onlyPromo || priceRange !== 'all') && (
            <button
              type="button"
              onClick={handleResetFilters}
              className="text-[#0066FF] hover:underline flex items-center gap-1 font-medium"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Limpar filtros</span>
            </button>
          )}
        </div>

        {/* Products Grid: 2 cols on mobile, 3 on tablet, 4 on desktop */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-6">
            {filteredProducts.map((product, index) => (
              <ScrollReveal
                key={product.id}
                delay={Math.min(index % 4, 3) * 60}
                duration={650}
                distance={24}
                className="h-full"
              >
                <ProductCard
                  product={product}
                  onViewProduct={onViewProduct}
                />
              </ScrollReveal>
            ))}
          </div>
        ) : (
          <div className="py-20 text-center rounded-2xl bg-zinc-950 border border-zinc-800 p-8">
            <div className="w-12 h-12 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center mx-auto mb-4 text-zinc-400">
              <Search className="w-6 h-6 text-zinc-500" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2 font-heading">
              Nenhum produto encontrado
            </h3>
            <p className="text-zinc-400 text-sm max-w-md mx-auto mb-6">
              Não encontramos nenhum item correspondente aos filtros selecionados. Tente buscar por outros termos ou redefinir os filtros.
            </p>
            <button
              type="button"
              onClick={handleResetFilters}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#0066FF] hover:bg-[#0055e6] text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Ver Todos os Produtos</span>
            </button>
          </div>
        )}

      </div>
    </section>
  );
};
