import React, { useState } from 'react';
import { Star, ShoppingBag, Eye, Check } from 'lucide-react';
import { Product, ProductSize } from '../types';
import { formatCurrency } from '../config/storeConfig';
import { useCart } from '../context/CartContext';

interface ProductCardProps {
  product: Product;
  onViewProduct: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onViewProduct }) => {
  const { addToCart } = useCart();
  const [selectedSize, setSelectedSize] = useState<ProductSize>(product.sizes[0] || 'M');
  const [isAdded, setIsAdded] = useState(false);

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, selectedSize, 1);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 1800);
  };

  return (
    <div 
      className="group relative flex flex-col bg-zinc-950/70 border border-zinc-800/90 hover:border-[#0066FF] rounded-2xl overflow-hidden transition-all duration-300 hover:shadow-xl hover:shadow-[#0066FF]/10 hover:-translate-y-1"
    >
      {/* Product Image and Badges */}
      <div 
        className="relative aspect-square w-full overflow-hidden bg-zinc-900 cursor-pointer"
        onClick={() => onViewProduct(product)}
      >
        <img
          src={product.images[0]}
          alt={product.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />

        {/* Gradient vignette */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

        {/* Top Badges */}
        <div className="absolute top-2.5 left-2.5 right-2.5 flex items-start justify-between pointer-events-none">
          <div className="flex flex-col gap-1">
            {product.discountPercent && (
              <span className="px-2 py-0.5 text-[11px] font-bold bg-[#0066FF] text-white rounded font-mono shadow-md">
                -{product.discountPercent}% OFF
              </span>
            )}
            {product.id.startsWith('znk-') && (
              <span className="px-2 py-0.5 text-[9px] font-bold bg-emerald-600/90 text-white rounded uppercase font-mono shadow-md">
                FOTO REAL
              </span>
            )}
            {product.isBestSeller && !product.discountPercent && (
              <span className="px-2 py-0.5 text-[10px] font-bold bg-white text-zinc-900 rounded uppercase font-mono shadow-md">
                MAIS VENDIDO
              </span>
            )}
            {product.isNewRelease && (
              <span className="px-2 py-0.5 text-[10px] font-bold bg-zinc-800 text-zinc-200 border border-zinc-700 rounded uppercase font-mono shadow-md">
                NOVO
              </span>
            )}
          </div>

          <span className="px-2 py-0.5 bg-black/75 backdrop-blur-md border border-zinc-700/60 rounded text-[10px] font-mono text-zinc-300">
            {product.category}
          </span>
        </div>

        {/* Quick View Button appearing on desktop hover */}
        <div className="absolute inset-x-3 bottom-3 hidden sm:flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onViewProduct(product);
            }}
            className="w-full py-2 bg-zinc-900/90 backdrop-blur-md hover:bg-black text-white text-xs font-semibold rounded-xl border border-zinc-700 flex items-center justify-center gap-1.5 transition-colors shadow-lg"
          >
            <Eye className="w-3.5 h-3.5 text-[#0066FF]" />
            <span>Ver Detalhes</span>
          </button>
        </div>
      </div>

      {/* Content Area */}
      <div className="p-3.5 sm:p-4 flex flex-col flex-grow justify-between bg-zinc-950">
        <div>
          {/* Rating */}
          <div className="flex items-center gap-1 text-xs text-zinc-400 mb-1.5">
            <div className="flex items-center text-amber-400">
              <Star className="w-3.5 h-3.5 fill-amber-400" />
            </div>
            <span className="font-semibold text-zinc-200">{product.rating.toFixed(1)}</span>
            <span className="text-zinc-600">·</span>
            <span className="text-[11px] text-zinc-400">({product.reviewsCount})</span>
          </div>

          {/* Title */}
          <h3 
            onClick={() => onViewProduct(product)}
            className="text-xs sm:text-sm font-bold text-white font-heading hover:text-[#3385ff] transition-colors cursor-pointer line-clamp-2 min-h-[36px]"
          >
            {product.name}
          </h3>

          {/* Pricing */}
          <div className="mt-2 flex items-baseline gap-2 flex-wrap">
            <span className="text-base sm:text-lg font-extrabold text-white font-mono">
              {formatCurrency(product.price)}
            </span>
            {product.originalPrice && (
              <span className="text-xs text-zinc-400 line-through font-mono">
                {formatCurrency(product.originalPrice)}
              </span>
            )}
          </div>

          <p className="text-[10px] text-zinc-400 mt-0.5">
            ou 3x de {formatCurrency(product.price / 3)} sem juros
          </p>

          {/* Size Selector */}
          <div className="mt-3 pt-3 border-t border-zinc-900 flex items-center justify-between">
            <span className="text-[10px] font-mono text-zinc-400 uppercase">Tam:</span>
            <div className="flex items-center gap-1">
              {product.sizes.map((sz) => (
                <button
                  key={sz}
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedSize(sz);
                  }}
                  className={`w-6 h-6 rounded text-[10px] font-mono font-bold transition-all ${
                    selectedSize === sz
                      ? 'bg-[#0066FF] text-white ring-1 ring-[#0066FF]'
                      : 'bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800 border border-zinc-800'
                  }`}
                >
                  {sz}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-3.5 pt-2 flex items-center gap-2">
          <button
            type="button"
            onClick={handleQuickAdd}
            disabled={isAdded}
            className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs uppercase tracking-wider transition-all duration-200 flex items-center justify-center gap-1.5 ${
              isAdded
                ? 'bg-emerald-600 text-white'
                : 'bg-zinc-900 hover:bg-[#0066FF] text-white hover:text-white border border-zinc-700/80 hover:border-[#0066FF]'
            }`}
          >
            {isAdded ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>Adicionado!</span>
              </>
            ) : (
              <>
                <ShoppingBag className="w-3.5 h-3.5 text-[#0066FF] group-hover:text-white transition-colors" />
                <span>Adicionar</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => onViewProduct(product)}
            className="sm:hidden p-2.5 bg-zinc-900 border border-zinc-800 text-zinc-300 rounded-xl hover:text-white"
            aria-label="Ver detalhes do produto"
          >
            <Eye className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
