import React, { useState, useEffect } from 'react';
import { 
  X, 
  Star, 
  Minus, 
  Plus, 
  ShoppingBag, 
  Zap, 
  Truck, 
  RefreshCw, 
  ShieldCheck, 
  Ruler, 
  Check, 
  ChevronRight,
  MessageCircle
} from 'lucide-react';
import { Product, ProductSize } from '../types';
import { formatCurrency, STORE_CONFIG, generateWhatsAppLink } from '../config/storeConfig';
import { useCart } from '../context/CartContext';
import { PRODUCTS } from '../data/products';
import { SizeGuideModal } from './SizeGuideModal';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  onSelectProduct: (p: Product) => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  onClose,
  onSelectProduct,
}) => {
  const { addToCart, openCheckout } = useCart();
  const [selectedImage, setSelectedImage] = useState<string>('');
  const [selectedSize, setSelectedSize] = useState<ProductSize>('M');
  const [quantity, setQuantity] = useState(1);
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);
  const [isAddedSuccess, setIsAddedSuccess] = useState(false);
  const [simulatedCep, setSimulatedCep] = useState('');
  const [shippingCalcResult, setShippingCalcResult] = useState<string | null>(null);

  useEffect(() => {
    if (product) {
      setSelectedImage(product.images[0]);
      setSelectedSize(product.sizes[0] || 'M');
      setQuantity(1);
      setIsAddedSuccess(false);
      setShippingCalcResult(null);
    }
  }, [product]);

  if (!product) return null;

  const handleAddToCart = () => {
    addToCart(product, selectedSize, quantity);
    setIsAddedSuccess(true);
    setTimeout(() => setIsAddedSuccess(false), 2200);
  };

  const handleBuyNow = () => {
    addToCart(product, selectedSize, quantity);
    onClose();
    openCheckout();
  };

  const handleBuyViaWhatsApp = () => {
    const total = product.price * quantity;
    const msg = `Olá ZNK STORE01! Tenho interesse em comprar:\n\n` +
      `👕 Produto: ${product.name}\n` +
      `📏 Tamanho: ${selectedSize}\n` +
      `🔢 Quantidade: ${quantity}\n` +
      `💰 Valor unitário: ${formatCurrency(product.price)}\n` +
      `💵 Total: ${formatCurrency(total)}\n\n` +
      `Gostaria de combinar a entrega para Rio Branco / envio!`;

    window.open(generateWhatsAppLink(msg), '_blank');
  };

  const handleCalcShipping = (e: React.FormEvent) => {
    e.preventDefault();
    if (!simulatedCep.trim()) return;
    
    // Simulate CEP check (detects Acre or outside)
    if (simulatedCep.startsWith('69') || simulatedCep.startsWith('68')) {
      setShippingCalcResult(`Entrega Expressa em Rio Branco - AC: R$ 10,00 (Receba em até 24h ou retire grátis no centro). Compras acima de R$ 199 têm FRETE GRÁTIS!`);
    } else {
      setShippingCalcResult(`Envio Nacional Correios/Transportadora: R$ 24,90 (4 a 8 dias úteis). Compras acima de R$ 199 têm FRETE GRÁTIS!`);
    }
  };

  // Related products from other products
  const relatedProducts = PRODUCTS.filter((p) => p.id !== product.id && (p.category === product.category || p.isBestSeller)).slice(0, 3);

  return (
    <>
      <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-fade-in">
        
        {/* Modal Container */}
        <div 
          className="relative w-full max-w-5xl bg-[#090A0F] border border-zinc-800 rounded-3xl shadow-2xl text-zinc-100 overflow-hidden my-auto max-h-[92vh] flex flex-col"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header Close button */}
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 z-20 p-2 text-zinc-400 hover:text-white bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-700/80 rounded-full transition-colors"
            aria-label="Fechar detalhes"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Modal Body */}
          <div className="overflow-y-auto p-4 sm:p-8 space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* Left Column: Image Gallery */}
              <div className="lg:col-span-6 space-y-4">
                {/* Main Image */}
                <div className="relative aspect-[4/5] rounded-2xl overflow-hidden bg-zinc-950 border border-zinc-800 shadow-lg">
                  <img
                    src={selectedImage || product.images[0]}
                    alt={product.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-center"
                  />
                  <div className="absolute top-3 left-3 flex flex-col gap-1.5">
                    {product.discountPercent && (
                      <span className="px-2.5 py-1 text-xs font-bold bg-[#0066FF] text-white rounded font-mono shadow-md">
                        -{product.discountPercent}% OFF
                      </span>
                    )}
                    <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-600/95 text-white rounded font-mono shadow-md flex items-center gap-1">
                      <Check className="w-3 h-3" /> FOTO REAL DO ESTOQUE
                    </span>
                  </div>
                </div>

                {/* Thumbnail row */}
                {product.images.length > 1 && (
                  <div className="flex items-center gap-3 overflow-x-auto pb-1">
                    {product.images.map((img, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setSelectedImage(img)}
                        className={`w-20 h-20 rounded-xl overflow-hidden border-2 transition-all shrink-0 ${
                          selectedImage === img
                            ? 'border-[#0066FF] ring-2 ring-[#0066FF]/30'
                            : 'border-zinc-800 opacity-60 hover:opacity-100'
                        }`}
                      >
                        <img 
                          src={img} 
                          alt={`${product.name} foto ${idx + 1}`} 
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover" 
                        />
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Right Column: Product Info & Actions */}
              <div className="lg:col-span-6 space-y-6">
                
                {/* Category & Rating */}
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="px-2.5 py-0.5 text-xs font-mono uppercase bg-zinc-900 border border-zinc-800 text-[#3385ff] rounded">
                      {product.category}
                    </span>
                    <span className="text-xs text-zinc-400 font-mono">
                      Ref: #{product.id.toUpperCase()}
                    </span>
                  </div>

                  <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-heading leading-tight uppercase">
                    {product.name}
                  </h1>

                  {/* Stars Rating */}
                  <div className="flex items-center gap-2 mt-2 text-xs">
                    <div className="flex items-center text-amber-400">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < Math.floor(product.rating)
                              ? 'fill-amber-400 text-amber-400'
                              : 'fill-zinc-800 text-zinc-700'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="font-bold text-white">{product.rating.toFixed(1)}</span>
                    <span className="text-zinc-600">·</span>
                    <span className="text-zinc-400">({product.reviewsCount} avaliações de clientes)</span>
                  </div>
                </div>

                {/* Pricing Block */}
                <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800/80">
                  <div className="flex items-baseline gap-3 flex-wrap">
                    <span className="text-3xl sm:text-4xl font-black text-white font-mono">
                      {formatCurrency(product.price)}
                    </span>
                    {product.originalPrice && (
                      <span className="text-base text-zinc-400 line-through font-mono">
                        {formatCurrency(product.originalPrice)}
                      </span>
                    )}
                    {product.discountPercent && (
                      <span className="px-2 py-0.5 text-xs font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-800/80 rounded">
                        Economize {formatCurrency((product.originalPrice || 0) - product.price)}
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-zinc-300 mt-1.5 flex items-center gap-1.5">
                    <span>ou em até <strong>3x sem juros</strong> de {formatCurrency(product.price / 3)}</span>
                  </p>
                  <p className="text-xs text-[#3385ff] mt-0.5 font-medium">
                    ⚡ <strong>5% de desconto no PIX:</strong> {formatCurrency(product.price * 0.95)}
                  </p>
                </div>

                {/* Description */}
                <div>
                  <p className="text-sm text-zinc-300 leading-relaxed">
                    {product.description}
                  </p>
                  {product.fabric && (
                    <div className="mt-3 p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 text-xs text-zinc-300">
                      <strong className="text-white">Composição:</strong> {product.fabric}
                    </div>
                  )}
                </div>

                {/* Size Selector & Guide */}
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold uppercase tracking-wider text-white">
                      Selecione o Tamanho:
                    </span>
                    <button
                      type="button"
                      onClick={() => setIsSizeGuideOpen(true)}
                      className="text-[#0066FF] hover:underline flex items-center gap-1 font-medium"
                    >
                      <Ruler className="w-3.5 h-3.5" />
                      <span>Guia de Medidas</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-2.5">
                    {product.sizes.map((sz) => (
                      <button
                        key={sz}
                        type="button"
                        onClick={() => setSelectedSize(sz)}
                        className={`w-12 h-12 rounded-xl font-mono font-bold text-sm transition-all flex items-center justify-center ${
                          selectedSize === sz
                            ? 'bg-[#0066FF] text-white ring-2 ring-[#0066FF]/50 shadow-lg shadow-[#0066FF]/20 scale-105'
                            : 'bg-zinc-900 border border-zinc-800 text-zinc-300 hover:border-zinc-700 hover:text-white'
                        }`}
                      >
                        {sz}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Quantity & Add to Cart Controls */}
                <div className="space-y-3">
                  <div className="flex items-center gap-4">
                    {/* Quantity counter */}
                    <div className="flex items-center bg-zinc-900 border border-zinc-800 rounded-xl p-1">
                      <button
                        type="button"
                        onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                        disabled={quantity <= 1}
                        className="p-2 text-zinc-400 hover:text-white disabled:opacity-30 rounded-lg hover:bg-zinc-800"
                        aria-label="Diminuir quantidade"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="w-10 text-center font-mono font-bold text-white text-sm">
                        {quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => setQuantity((q) => q + 1)}
                        className="p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800"
                        aria-label="Aumentar quantidade"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Add to Cart button */}
                    <button
                      type="button"
                      onClick={handleAddToCart}
                      className={`flex-1 py-3.5 px-6 rounded-xl font-bold text-xs sm:text-sm uppercase tracking-wider transition-all duration-200 flex items-center justify-center gap-2 ${
                        isAddedSuccess
                          ? 'bg-emerald-600 text-white'
                          : 'bg-zinc-900 hover:bg-zinc-800 text-white border border-zinc-700 hover:border-[#0066FF]'
                      }`}
                    >
                      {isAddedSuccess ? (
                        <>
                          <Check className="w-4 h-4" />
                          <span>Adicionado ao Carrinho!</span>
                        </>
                      ) : (
                        <>
                          <ShoppingBag className="w-4 h-4 text-[#0066FF]" />
                          <span>Adicionar ao Carrinho</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Buy Now & WhatsApp Actions */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={handleBuyNow}
                      className="py-3.5 px-4 bg-[#0066FF] hover:bg-[#0055e6] text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all box-glow-blue flex items-center justify-center gap-2 shadow-lg"
                    >
                      <Zap className="w-4 h-4 fill-white" />
                      <span>Comprar Agora</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleBuyViaWhatsApp}
                      className="py-3.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg"
                    >
                      <MessageCircle className="w-4 h-4 fill-white" />
                      <span>Pedir pelo WhatsApp</span>
                    </button>
                  </div>
                </div>

                {/* Shipping Estimator */}
                <div className="pt-4 border-t border-zinc-800/80 space-y-3">
                  <div className="flex items-center gap-2 text-xs font-semibold text-white">
                    <Truck className="w-4 h-4 text-[#0066FF]" />
                    <span>Calcular Envio e Prazo:</span>
                  </div>

                  <form onSubmit={handleCalcShipping} className="flex gap-2">
                    <input
                      type="text"
                      value={simulatedCep}
                      onChange={(e) => setSimulatedCep(e.target.value)}
                      placeholder="Ex: 69900-000 (Rio Branco)"
                      className="flex-1 bg-zinc-900 border border-zinc-800 focus:border-[#0066FF] text-white text-xs rounded-xl px-3 py-2.5 focus:outline-none"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-semibold rounded-xl transition-colors"
                    >
                      Calcular
                    </button>
                  </form>

                  {shippingCalcResult && (
                    <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl text-xs text-zinc-300 leading-relaxed">
                      {shippingCalcResult}
                    </div>
                  )}

                  {/* Trust guarantees */}
                  <div className="grid grid-cols-2 gap-2 pt-2 text-[11px] text-zinc-400">
                    <div className="flex items-center gap-1.5">
                      <RefreshCw className="w-3.5 h-3.5 text-[#0066FF]" />
                      <span>1ª Troca Grátis em até 7 dias</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-[#0066FF]" />
                      <span>Produto 100% Original ZNK</span>
                    </div>
                  </div>
                </div>

              </div>

            </div>

            {/* Related Products Section */}
            {relatedProducts.length > 0 && (
              <div className="pt-8 border-t border-zinc-800">
                <h3 className="text-base font-bold text-white font-heading uppercase mb-4 flex items-center justify-between">
                  <span>Produtos Relacionados</span>
                  <span className="text-xs text-zinc-400 font-mono">COMPLETE SEU LOOK</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {relatedProducts.map((rel) => (
                    <div
                      key={rel.id}
                      onClick={() => onSelectProduct(rel)}
                      className="group cursor-pointer p-3 rounded-2xl bg-zinc-950 border border-zinc-800/80 hover:border-[#0066FF] transition-all flex items-center gap-3"
                    >
                      <div className="w-16 h-16 rounded-xl overflow-hidden bg-zinc-900 shrink-0">
                        <img src={rel.images[0]} alt={rel.name} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-bold text-white truncate group-hover:text-[#3385ff]">
                          {rel.name}
                        </h4>
                        <p className="text-xs font-mono font-bold text-white mt-0.5">
                          {formatCurrency(rel.price)}
                        </p>
                      </div>
                      <ChevronRight className="w-4 h-4 text-zinc-600 group-hover:text-[#0066FF]" />
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>

        </div>
      </div>

      {/* Size Guide Modal */}
      <SizeGuideModal
        isOpen={isSizeGuideOpen}
        onClose={() => setIsSizeGuideOpen(false)}
      />
    </>
  );
};
