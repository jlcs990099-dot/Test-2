import React from 'react';
import { X, Ruler, CheckCircle2 } from 'lucide-react';

interface SizeGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SizeGuideModal: React.FC<SizeGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-fade-in">
      <div 
        className="relative w-full max-w-lg bg-[#0D0F14] border border-zinc-800 rounded-2xl p-6 shadow-2xl text-zinc-100 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <Ruler className="w-5 h-5 text-[#0066FF]" />
            <h3 className="text-lg font-bold text-white font-heading uppercase">
              Tabela de Medidas ZNK
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="py-4 space-y-6 text-sm">
          <div>
            <h4 className="font-semibold text-white mb-2 text-xs uppercase tracking-wider text-[#3385ff]">
              1. Camisetas & Oversized (em centímetros)
            </h4>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border border-zinc-800">
                <thead className="bg-zinc-900 text-zinc-300">
                  <tr>
                    <th className="p-2.5 border-b border-zinc-800">Tamanho</th>
                    <th className="p-2.5 border-b border-zinc-800">Tórax / Peito</th>
                    <th className="p-2.5 border-b border-zinc-800">Comprimento</th>
                    <th className="p-2.5 border-b border-zinc-800">Manga</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/60 font-mono">
                  <tr>
                    <td className="p-2.5 font-bold text-white">P</td>
                    <td className="p-2.5 text-zinc-300">54 cm</td>
                    <td className="p-2.5 text-zinc-300">73 cm</td>
                    <td className="p-2.5 text-zinc-300">23 cm</td>
                  </tr>
                  <tr>
                    <td className="p-2.5 font-bold text-white">M</td>
                    <td className="p-2.5 text-zinc-300">57 cm</td>
                    <td className="p-2.5 text-zinc-300">76 cm</td>
                    <td className="p-2.5 text-zinc-300">24 cm</td>
                  </tr>
                  <tr>
                    <td className="p-2.5 font-bold text-white">G</td>
                    <td className="p-2.5 text-zinc-300">60 cm</td>
                    <td className="p-2.5 text-zinc-300">79 cm</td>
                    <td className="p-2.5 text-zinc-300">25 cm</td>
                  </tr>
                  <tr>
                    <td className="p-2.5 font-bold text-white">GG</td>
                    <td className="p-2.5 text-zinc-300">63 cm</td>
                    <td className="p-2.5 text-zinc-300">82 cm</td>
                    <td className="p-2.5 text-zinc-300">26 cm</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-2 text-xs uppercase tracking-wider text-[#3385ff]">
              2. Shorts & Bermudas (em centímetros)
            </h4>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border border-zinc-800">
                <thead className="bg-zinc-900 text-zinc-300">
                  <tr>
                    <th className="p-2.5 border-b border-zinc-800">Tamanho</th>
                    <th className="p-2.5 border-b border-zinc-800">Cintura (elástico esticado)</th>
                    <th className="p-2.5 border-b border-zinc-800">Comprimento</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/60 font-mono">
                  <tr>
                    <td className="p-2.5 font-bold text-white">P (36-38)</td>
                    <td className="p-2.5 text-zinc-300">72 - 82 cm</td>
                    <td className="p-2.5 text-zinc-300">43 cm</td>
                  </tr>
                  <tr>
                    <td className="p-2.5 font-bold text-white">M (40-42)</td>
                    <td className="p-2.5 text-zinc-300">78 - 88 cm</td>
                    <td className="p-2.5 text-zinc-300">45 cm</td>
                  </tr>
                  <tr>
                    <td className="p-2.5 font-bold text-white">G (44)</td>
                    <td className="p-2.5 text-zinc-300">84 - 94 cm</td>
                    <td className="p-2.5 text-zinc-300">47 cm</td>
                  </tr>
                  <tr>
                    <td className="p-2.5 font-bold text-white">GG (46)</td>
                    <td className="p-2.5 text-zinc-300">90 - 102 cm</td>
                    <td className="p-2.5 text-zinc-300">49 cm</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div className="p-4 bg-zinc-900/80 rounded-xl border border-zinc-800 text-xs text-zinc-300 space-y-2">
            <div className="flex items-center gap-2 font-semibold text-white">
              <CheckCircle2 className="w-4 h-4 text-[#0066FF]" />
              <span>Dica de Caimento ZNK:</span>
            </div>
            <p>
              As peças <strong>Oversized</strong> já possuem modelagem ampla proposital. Se você prefere um caimento streetwear padrão solto, escolha o seu tamanho habitual. Se deseja um visual mais ajustado ao corpo, escolha um tamanho menor.
            </p>
          </div>
        </div>

        <div className="pt-4 border-t border-zinc-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-semibold rounded-lg transition-colors"
          >
            Entendi, fechar
          </button>
        </div>
      </div>
    </div>
  );
};
