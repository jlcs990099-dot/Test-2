import React from 'react';
import { ArrowUpRight } from 'lucide-react';
import { CATEGORIES } from '../data/categories';
import { ProductCategory } from '../types';
import { ScrollReveal } from './ScrollReveal';

interface CategoriesSectionProps {
  onSelectCategory: (category: ProductCategory) => void;
}

export const CategoriesSection: React.FC<CategoriesSectionProps> = ({ onSelectCategory }) => {
  return (
    <section id="categorias" className="py-16 sm:py-24 border-b border-zinc-800/80 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <ScrollReveal duration={600} distance={28}>
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 sm:mb-14 gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="w-2.5 h-0.5 bg-[#0066FF]" />
                <span className="text-xs font-mono uppercase tracking-widest text-[#0066FF] font-semibold">
                  CATEGORIAS EM DESTAQUE
                </span>
              </div>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white uppercase font-heading tracking-tight">
                ENCONTRE SEU <span className="text-[#0066FF]">ESTILO</span>
              </h2>
            </div>
            <p className="text-zinc-400 text-sm max-w-md">
              Do oversized clássico aos shorts táticos e acessórios. Selecione sua categoria e monte seu visual streetwear completo.
            </p>
          </div>
        </ScrollReveal>

        {/* Categories Grid with Staggered Fade-in Up */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4 lg:gap-5">
          {CATEGORIES.map((cat, index) => (
            <ScrollReveal
              key={cat.id}
              delay={index * 70}
              duration={650}
              distance={30}
              className="h-full"
            >
              <div
                onClick={() => onSelectCategory(cat.id)}
                className="group relative cursor-pointer rounded-2xl overflow-hidden bg-zinc-900 border border-zinc-800 hover:border-[#0066FF] transition-all duration-300 flex flex-col hover:shadow-xl hover:shadow-[#0066FF]/10 hover:-translate-y-1 h-full"
              >
                {/* Image Aspect ratio container */}
                <div className="aspect-[3/4] w-full overflow-hidden relative bg-zinc-950">
                  <img
                    src={cat.image}
                    alt={`Categoria ${cat.title} ZNK STORE01`}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-500 opacity-90 group-hover:opacity-100"
                    loading="lazy"
                  />
                  
                  {/* Gradient shade */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />

                  {/* Top Corner indicator */}
                  <div className="absolute top-2.5 right-2.5 w-7 h-7 rounded-full bg-zinc-900/80 border border-zinc-700/60 flex items-center justify-center text-zinc-300 group-hover:bg-[#0066FF] group-hover:text-white group-hover:border-[#0066FF] transition-colors">
                    <ArrowUpRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </div>
                </div>

                {/* Card Footer */}
                <div className="p-3 sm:p-4 bg-zinc-950 flex flex-col justify-between flex-grow border-t border-zinc-800/80">
                  <div>
                    <h3 className="text-sm sm:text-base font-bold text-white font-heading uppercase group-hover:text-[#3385ff] transition-colors">
                      {cat.title}
                    </h3>
                    <p className="text-[11px] text-zinc-400 line-clamp-1 mt-0.5 hidden sm:block">
                      {cat.subtitle}
                    </p>
                  </div>

                  <div className="mt-3 pt-2 border-t border-zinc-900 flex items-center justify-between">
                    <span className="text-[11px] font-semibold text-[#0066FF] group-hover:underline">
                      Ver produtos
                    </span>
                    <span className="text-[10px] text-zinc-400 font-mono">
                      {cat.itemCount} peças
                    </span>
                  </div>
                </div>

              </div>
            </ScrollReveal>
          ))}
        </div>

      </div>
    </section>
  );
};
