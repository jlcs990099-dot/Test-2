import React, { useState } from 'react';
import { 
  X, 
  CheckCircle2, 
  QrCode, 
  CreditCard, 
  Banknote, 
  Copy, 
  Check, 
  MessageCircle, 
  ArrowRight, 
  ShieldCheck, 
  MapPin, 
  ShoppingBag,
  ExternalLink
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAdmin } from '../context/AdminContext';
import { CheckoutForm, OrderConfirmationData } from '../types';
import { STORE_CONFIG, formatCurrency, generateWhatsAppLink } from '../config/storeConfig';

export const CheckoutModal: React.FC = () => {
  const {
    items,
    subtotal,
    clearCart,
    isCheckoutOpen,
    closeCheckout,
    confirmedOrder,
    setConfirmedOrder,
  } = useCart();
  const { addOrder } = useAdmin();

  const [formData, setFormData] = useState<CheckoutForm>({
    fullName: '',
    whatsapp: '',
    email: '',
    cep: '69900-000',
    state: 'Acre (AC)',
    city: 'Rio Branco',
    neighborhood: 'Centro',
    street: 'Avenida Brasil',
    number: '',
    complement: '',
    paymentMethod: 'pix',
    notes: '',
  });

  const [isCopiedPix, setIsCopiedPix] = useState(false);
  const [cardData, setCardData] = useState({
    cardNumber: '•••• •••• •••• 4242',
    holderName: '',
    expiry: '12/28',
    cvv: '•••',
    installments: '1',
  });
  const [cashChange, setCashChange] = useState('');

  if (!isCheckoutOpen) return null;

  // Shipping calculation
  const isFreeShipping = subtotal >= STORE_CONFIG.freeShippingThreshold;
  const shippingCost = isFreeShipping ? 0 : STORE_CONFIG.localShippingRate;

  // PIX discount (5% off)
  const isPix = formData.paymentMethod === 'pix';
  const pixDiscount = isPix ? (subtotal * STORE_CONFIG.pixDiscountPercent) / 100 : 0;
  const finalTotal = subtotal - pixDiscount + shippingCost;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleCopyPix = () => {
    navigator.clipboard.writeText(STORE_CONFIG.pixKey);
    setIsCopiedPix(true);
    setTimeout(() => setIsCopiedPix(false), 2500);
  };

  const handleFillDemoData = () => {
    setFormData({
      fullName: 'Lucas Pinheiro da Silva',
      whatsapp: '(68) 99234-5678',
      email: 'lucas.pinheiro@email.com',
      cep: '69900-120',
      state: 'Acre (AC)',
      city: 'Rio Branco',
      neighborhood: 'Bosque',
      street: 'Rua Benjamin Constant',
      number: '482',
      complement: 'Apt 302',
      paymentMethod: 'pix',
      notes: 'Entregar preferencialmente no período da tarde',
    });
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.fullName.trim() || !formData.whatsapp.trim()) {
      alert('Por favor, preencha pelo menos o seu nome completo e WhatsApp para contato.');
      return;
    }

    const orderId = `ZNK-${Math.floor(10000 + Math.random() * 90000)}`;
    const newOrder: OrderConfirmationData = {
      orderId,
      customer: formData,
      items: [...items],
      subtotal,
      discount: pixDiscount,
      shipping: shippingCost,
      total: finalTotal,
      status: formData.paymentMethod === 'pix' ? 'pago' : 'pendente',
      createdAt: new Date().toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
    };

    addOrder(newOrder);
    setConfirmedOrder(newOrder);
    clearCart();
  };

  const handleSendOrderToWhatsApp = (order: OrderConfirmationData) => {
    const itemsList = order.items
      .map(
        (it, idx) =>
          `${idx + 1}. *${it.product.name}*\n   Tamanho: ${it.size} | Qtd: ${it.quantity} | Valor: ${formatCurrency(
            it.product.price * it.quantity
          )}`
      )
      .join('\n\n');

    const paymentLabel =
      order.customer.paymentMethod === 'pix'
        ? 'PIX (5% de Desconto aplicado)'
        : order.customer.paymentMethod === 'credit_card'
        ? 'Cartão de Crédito'
        : 'Dinheiro na Entrega';

    const msg =
      `🎉 *PEDIDO CONFIRMADO #${order.orderId} - ZNK STORE01*\n\n` +
      `👤 *Cliente:* ${order.customer.fullName}\n` +
      `📱 *WhatsApp:* ${order.customer.whatsapp}\n` +
      `📍 *Endereço:* ${order.customer.street}, ${order.customer.number || 'S/N'}${order.customer.complement ? ' (' + order.customer.complement + ')' : ''} - ${order.customer.neighborhood}, ${order.customer.city} - ${order.customer.state}\n` +
      `💳 *Forma de Pagamento:* ${paymentLabel}\n\n` +
      `🛍️ *ITENS DO PEDIDO:*\n${itemsList}\n\n` +
      `📦 *Subtotal:* ${formatCurrency(order.subtotal)}\n` +
      (order.discount > 0 ? `⚡ *Desconto PIX (5%):* -${formatCurrency(order.discount)}\n` : '') +
      `🚚 *Frete:* ${order.shipping === 0 ? 'GRÁTIS' : formatCurrency(order.shipping)}\n` +
      `💰 *TOTAL FINAL:* ${formatCurrency(order.total)}\n\n` +
      (order.customer.notes ? `📝 *Observações:* ${order.customer.notes}\n\n` : '') +
      `Olá! Acabei de registrar este pedido na loja virtual da ZNK STORE01. Podem me confirmar a entrega?`;

    window.open(generateWhatsAppLink(msg), '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-fade-in">
      <div 
        className="relative w-full max-w-4xl bg-[#090A0F] border border-zinc-800 rounded-3xl shadow-2xl text-zinc-100 overflow-hidden my-auto max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-zinc-900 border border-[#0066FF] flex items-center justify-center text-white font-bold text-sm">
              Z
            </div>
            <div>
              <h2 className="text-lg font-bold text-white font-heading uppercase">
                {confirmedOrder ? 'PEDIDO CONFIRMADO' : 'FINALIZAR PEDIDO'}
              </h2>
              <p className="text-xs text-zinc-400 font-mono">
                {confirmedOrder ? `Protocolo #${confirmedOrder.orderId}` : 'ZNK STORE01 · Rio Branco - AC'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              closeCheckout();
              setConfirmedOrder(null);
            }}
            className="p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800"
            aria-label="Fechar checkout"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body content */}
        <div className="overflow-y-auto p-4 sm:p-8 flex-1">
          {confirmedOrder ? (
            /* SUCCESS CONFIRMATION STATE */
            <div className="space-y-6 text-center max-w-2xl mx-auto py-4">
              <div className="w-20 h-20 rounded-full bg-[#0066FF]/20 border border-[#0066FF] flex items-center justify-center mx-auto text-[#0066FF] box-glow-blue animate-bounce">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <span className="px-3 py-1 bg-emerald-950/80 border border-emerald-700/80 text-emerald-400 text-xs font-mono font-bold rounded-full uppercase">
                  PEDIDO RECEBIDO COM SUCESSO!
                </span>
                <h1 className="text-3xl sm:text-4xl font-black text-white font-heading mt-3 uppercase">
                  OBRIGADO POR COMPRAR NA <span className="text-[#0066FF]">ZNK STORE01</span>
                </h1>
                <p className="text-zinc-300 text-sm mt-2">
                  Recebemos os detalhes do seu pedido com sucesso. Nossa equipe já está separando suas peças com todo o cuidado!
                </p>
              </div>

              {/* Order Info Card */}
              <div className="p-5 rounded-2xl bg-zinc-950 border border-zinc-800 text-left space-y-4">
                <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                  <div>
                    <p className="text-xs text-zinc-400">Número do Pedido:</p>
                    <p className="font-mono font-black text-white text-base">#{confirmedOrder.orderId}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-zinc-400">Total do Pedido:</p>
                    <p className="font-mono font-black text-[#0066FF] text-lg">
                      {formatCurrency(confirmedOrder.total)}
                    </p>
                  </div>
                </div>

                <div className="text-xs text-zinc-300 space-y-1">
                  <p><strong>Cliente:</strong> {confirmedOrder.customer.fullName}</p>
                  <p><strong>WhatsApp:</strong> {confirmedOrder.customer.whatsapp}</p>
                  <p><strong>Entrega em:</strong> {confirmedOrder.customer.street}, {confirmedOrder.customer.number} - {confirmedOrder.customer.neighborhood}, {confirmedOrder.customer.city} - {confirmedOrder.customer.state}</p>
                  <p>
                    <strong>Forma de Pagamento:</strong>{' '}
                    {confirmedOrder.customer.paymentMethod === 'pix'
                      ? 'PIX (5% OFF aplicado)'
                      : confirmedOrder.customer.paymentMethod === 'credit_card'
                      ? 'Cartão de Crédito'
                      : 'Dinheiro na Entrega'}
                  </p>
                </div>

                {/* Items summary */}
                <div className="pt-2 border-t border-zinc-850">
                  <p className="text-xs font-bold text-zinc-400 uppercase mb-2">Itens Inclusos:</p>
                  <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                    {confirmedOrder.items.map((it, idx) => (
                      <div key={idx} className="flex justify-between text-xs text-zinc-300">
                        <span className="truncate max-w-[280px]">
                          {it.quantity}x {it.product.name} ({it.size})
                        </span>
                        <span className="font-mono text-white font-semibold">
                          {formatCurrency(it.product.price * it.quantity)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* WhatsApp notification CTA */}
              <div className="p-4 rounded-2xl bg-[#0066FF]/10 border border-[#0066FF]/40 text-left flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <MessageCircle className="w-4 h-4 text-[#3385ff]" />
                    <span>Acelere sua entrega pelo WhatsApp</span>
                  </h4>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    Envie os dados do pedido direto para a nossa equipe no Acre para agilizar a separação e entrega.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => handleSendOrderToWhatsApp(confirmedOrder)}
                  className="w-full sm:w-auto px-5 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-2 shrink-0 shadow-lg"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Enviar no WhatsApp</span>
                </button>
              </div>

              {/* Return to shop */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    closeCheckout();
                    setConfirmedOrder(null);
                  }}
                  className="px-6 py-2.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 text-xs font-semibold rounded-xl border border-zinc-700 transition-colors"
                >
                  Voltar para a Loja
                </button>
              </div>
            </div>
          ) : (
            /* CHECKOUT FORM */
            <form onSubmit={handleSubmitOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Left Column: Customer & Delivery Address */}
              <div className="lg:col-span-7 space-y-6">
                
                {/* Demo Helper Button */}
                <div className="flex items-center justify-between p-3 rounded-xl bg-zinc-950 border border-zinc-800">
                  <span className="text-xs text-zinc-400">Protótipo interativo:</span>
                  <button
                    type="button"
                    onClick={handleFillDemoData}
                    className="text-xs font-semibold text-[#0066FF] hover:underline"
                  >
                    ⚡ Auto-preencher dados de Rio Branco
                  </button>
                </div>

                {/* 1. Customer Personal Details */}
                <div>
                  <h3 className="text-sm font-bold text-white uppercase font-heading tracking-wider mb-3 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#0066FF] text-white flex items-center justify-center text-[10px] font-mono">1</span>
                    <span>Dados de Contato</span>
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-medium text-zinc-400 mb-1">
                        Nome Completo *
                      </label>
                      <input
                        type="text"
                        name="fullName"
                        required
                        value={formData.fullName}
                        onChange={handleInputChange}
                        placeholder="Ex: Matheus Albuquerque"
                        className="w-full bg-zinc-900 border border-zinc-800 focus:border-[#0066FF] text-white text-xs sm:text-sm rounded-xl px-3.5 py-2.5 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-zinc-400 mb-1">
                        WhatsApp (com DDD) *
                      </label>
                      <input
                        type="tel"
                        name="whatsapp"
                        required
                        value={formData.whatsapp}
                        onChange={handleInputChange}
                        placeholder="(68) 99999-9999"
                        className="w-full bg-zinc-900 border border-zinc-800 focus:border-[#0066FF] text-white text-xs sm:text-sm rounded-xl px-3.5 py-2.5 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-zinc-400 mb-1">
                        E-mail para confirmação
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="seuemail@exemplo.com"
                        className="w-full bg-zinc-900 border border-zinc-800 focus:border-[#0066FF] text-white text-xs sm:text-sm rounded-xl px-3.5 py-2.5 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* 2. Delivery Address */}
                <div>
                  <h3 className="text-sm font-bold text-white uppercase font-heading tracking-wider mb-3 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#0066FF] text-white flex items-center justify-center text-[10px] font-mono">2</span>
                    <span>Endereço de Entrega</span>
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-6 gap-3">
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-medium text-zinc-400 mb-1">
                        CEP
                      </label>
                      <input
                        type="text"
                        name="cep"
                        value={formData.cep}
                        onChange={handleInputChange}
                        placeholder="69900-000"
                        className="w-full bg-zinc-900 border border-zinc-800 focus:border-[#0066FF] text-white text-xs sm:text-sm rounded-xl px-3.5 py-2.5 focus:outline-none"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-medium text-zinc-400 mb-1">
                        Estado
                      </label>
                      <input
                        type="text"
                        name="state"
                        value={formData.state}
                        onChange={handleInputChange}
                        className="w-full bg-zinc-900 border border-zinc-800 text-white text-xs sm:text-sm rounded-xl px-3.5 py-2.5 focus:outline-none"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-medium text-zinc-400 mb-1">
                        Cidade
                      </label>
                      <input
                        type="text"
                        name="city"
                        value={formData.city}
                        onChange={handleInputChange}
                        className="w-full bg-zinc-900 border border-zinc-800 text-white text-xs sm:text-sm rounded-xl px-3.5 py-2.5 focus:outline-none"
                      />
                    </div>

                    <div className="sm:col-span-3">
                      <label className="block text-xs font-medium text-zinc-400 mb-1">
                        Bairro *
                      </label>
                      <input
                        type="text"
                        name="neighborhood"
                        required
                        value={formData.neighborhood}
                        onChange={handleInputChange}
                        placeholder="Ex: Bosque, Centro, Floresta"
                        className="w-full bg-zinc-900 border border-zinc-800 focus:border-[#0066FF] text-white text-xs sm:text-sm rounded-xl px-3.5 py-2.5 focus:outline-none"
                      />
                    </div>

                    <div className="sm:col-span-3">
                      <label className="block text-xs font-medium text-zinc-400 mb-1">
                        Rua / Avenida *
                      </label>
                      <input
                        type="text"
                        name="street"
                        required
                        value={formData.street}
                        onChange={handleInputChange}
                        placeholder="Ex: Rua Isaura Parente"
                        className="w-full bg-zinc-900 border border-zinc-800 focus:border-[#0066FF] text-white text-xs sm:text-sm rounded-xl px-3.5 py-2.5 focus:outline-none"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-medium text-zinc-400 mb-1">
                        Número *
                      </label>
                      <input
                        type="text"
                        name="number"
                        required
                        value={formData.number}
                        onChange={handleInputChange}
                        placeholder="123"
                        className="w-full bg-zinc-900 border border-zinc-800 focus:border-[#0066FF] text-white text-xs sm:text-sm rounded-xl px-3.5 py-2.5 focus:outline-none"
                      />
                    </div>

                    <div className="sm:col-span-4">
                      <label className="block text-xs font-medium text-zinc-400 mb-1">
                        Complemento (opcional)
                      </label>
                      <input
                        type="text"
                        name="complement"
                        value={formData.complement}
                        onChange={handleInputChange}
                        placeholder="Apto 101, Bloco B, Próximo ao mercado"
                        className="w-full bg-zinc-900 border border-zinc-800 focus:border-[#0066FF] text-white text-xs sm:text-sm rounded-xl px-3.5 py-2.5 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* 3. Payment Method */}
                <div>
                  <h3 className="text-sm font-bold text-white uppercase font-heading tracking-wider mb-3 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#0066FF] text-white flex items-center justify-center text-[10px] font-mono">3</span>
                    <span>FORMA DE PAGAMENTO</span>
                  </h3>

                  {/* Payment option selectors */}
                  <div className="grid grid-cols-3 gap-2 sm:gap-3 mb-4">
                    {/* PIX */}
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, paymentMethod: 'pix' })}
                      className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center justify-center gap-1.5 ${
                        formData.paymentMethod === 'pix'
                          ? 'bg-[#0066FF]/20 border-[#0066FF] text-white box-glow-blue-subtle'
                          : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-700'
                      }`}
                    >
                      <QrCode className="w-5 h-5 text-[#3385ff]" />
                      <span className="text-xs font-bold uppercase">PIX</span>
                      <span className="text-[10px] text-emerald-400 font-bold">5% OFF</span>
                    </button>

                    {/* Cartão */}
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, paymentMethod: 'credit_card' })}
                      className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center justify-center gap-1.5 ${
                        formData.paymentMethod === 'credit_card'
                          ? 'bg-[#0066FF]/20 border-[#0066FF] text-white box-glow-blue-subtle'
                          : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-700'
                      }`}
                    >
                      <CreditCard className="w-5 h-5 text-[#3385ff]" />
                      <span className="text-xs font-bold uppercase">Cartão</span>
                      <span className="text-[10px] text-zinc-400">Até 3x sem juros</span>
                    </button>

                    {/* Dinheiro */}
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, paymentMethod: 'cash_on_delivery' })}
                      className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center justify-center gap-1.5 ${
                        formData.paymentMethod === 'cash_on_delivery'
                          ? 'bg-[#0066FF]/20 border-[#0066FF] text-white box-glow-blue-subtle'
                          : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-700'
                      }`}
                    >
                      <Banknote className="w-5 h-5 text-[#3385ff]" />
                      <span className="text-xs font-bold uppercase">Dinheiro</span>
                      <span className="text-[10px] text-zinc-400">Na entrega</span>
                    </button>
                  </div>

                  {/* Payment Method Details */}
                  {formData.paymentMethod === 'pix' && (
                    <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-3">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-white">Chave PIX ZNK STORE01 (E-mail):</span>
                        <span className="text-emerald-400 font-mono font-bold">Aprovação Imediata</span>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          readOnly
                          value={STORE_CONFIG.pixKey}
                          className="flex-1 bg-zinc-900 border border-zinc-800 text-white font-mono text-xs rounded-xl px-3 py-2.5 focus:outline-none"
                        />
                        <button
                          type="button"
                          onClick={handleCopyPix}
                          className="px-3.5 py-2.5 bg-[#0066FF] hover:bg-[#0055e6] text-white text-xs font-semibold rounded-xl transition-colors flex items-center gap-1.5"
                        >
                          {isCopiedPix ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{isCopiedPix ? 'Copiado!' : 'Copiar'}</span>
                        </button>
                      </div>

                      <p className="text-[11px] text-zinc-400">
                        O QR Code e confirmação serão validados após a finalização. Você também poderá enviar o comprovante diretamente pelo WhatsApp.
                      </p>
                    </div>
                  )}

                  {formData.paymentMethod === 'credit_card' && (
                    <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div className="col-span-2">
                          <label className="block text-[11px] text-zinc-400 mb-1">Número do Cartão</label>
                          <input
                            type="text"
                            value={cardData.cardNumber}
                            onChange={(e) => setCardData({ ...cardData, cardNumber: e.target.value })}
                            placeholder="4532 0000 0000 0000"
                            className="w-full bg-zinc-900 border border-zinc-800 text-white font-mono text-xs rounded-xl px-3 py-2"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-zinc-400 mb-1">Validade</label>
                          <input
                            type="text"
                            value={cardData.expiry}
                            onChange={(e) => setCardData({ ...cardData, expiry: e.target.value })}
                            placeholder="MM/AA"
                            className="w-full bg-zinc-900 border border-zinc-800 text-white font-mono text-xs rounded-xl px-3 py-2"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-zinc-400 mb-1">CVV</label>
                          <input
                            type="text"
                            value={cardData.cvv}
                            onChange={(e) => setCardData({ ...cardData, cvv: e.target.value })}
                            placeholder="123"
                            className="w-full bg-zinc-900 border border-zinc-800 text-white font-mono text-xs rounded-xl px-3 py-2"
                          />
                        </div>
                        <div className="col-span-2">
                          <label className="block text-[11px] text-zinc-400 mb-1">Parcelamento</label>
                          <select
                            value={cardData.installments}
                            onChange={(e) => setCardData({ ...cardData, installments: e.target.value })}
                            className="w-full bg-zinc-900 border border-zinc-800 text-white text-xs rounded-xl px-3 py-2"
                          >
                            <option value="1">1x de {formatCurrency(finalTotal)} sem juros</option>
                            <option value="2">2x de {formatCurrency(finalTotal / 2)} sem juros</option>
                            <option value="3">3x de {formatCurrency(finalTotal / 3)} sem juros</option>
                          </select>
                        </div>
                      </div>
                      <p className="text-[10px] text-zinc-400">
                        * Demonstração visual do protótipo ZNK STORE01. Nenhum débito real será efetuado.
                      </p>
                    </div>
                  )}

                  {formData.paymentMethod === 'cash_on_delivery' && (
                    <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-2">
                      <p className="text-xs text-zinc-300 font-semibold">
                        Pagamento no ato da entrega em Rio Branco - AC
                      </p>
                      <label className="block text-[11px] text-zinc-400">
                        Precisa de troco para quanto? (Deixe em branco se tiver o valor exato)
                      </label>
                      <input
                        type="text"
                        value={cashChange}
                        onChange={(e) => setCashChange(e.target.value)}
                        placeholder="Ex: Troco para R$ 200,00"
                        className="w-full bg-zinc-900 border border-zinc-800 text-white text-xs rounded-xl px-3 py-2"
                      />
                    </div>
                  )}
                </div>

              </div>

              {/* Right Column: Order Summary & Confirmation CTA */}
              <div className="lg:col-span-5 space-y-5">
                <div className="p-5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-4">
                  <h3 className="text-sm font-bold text-white uppercase font-heading tracking-wider flex items-center justify-between">
                    <span>Resumo do Pedido</span>
                    <span className="text-xs font-mono text-[#0066FF]">{items.length} itens</span>
                  </h3>

                  {/* Items miniature list */}
                  <div className="space-y-3 max-h-56 overflow-y-auto pr-1 border-b border-zinc-850 pb-3">
                    {items.map((it) => (
                      <div key={`${it.product.id}-${it.size}`} className="flex items-center gap-3">
                        <img
                          src={it.product.images[0]}
                          alt={it.product.name}
                          referrerPolicy="no-referrer"
                          className="w-12 h-12 rounded-lg object-cover bg-zinc-900 shrink-0 border border-zinc-800"
                        />
                        <div className="flex-1 min-w-0 text-xs">
                          <h4 className="text-white font-bold truncate">{it.product.name}</h4>
                          <p className="text-zinc-400">
                            Tam: <strong className="text-white">{it.size}</strong> · Qtd: {it.quantity}
                          </p>
                        </div>
                        <span className="font-mono text-xs font-bold text-white shrink-0">
                          {formatCurrency(it.product.price * it.quantity)}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Calculations breakdown */}
                  <div className="space-y-2 text-xs text-zinc-400">
                    <div className="flex justify-between">
                      <span>Subtotal</span>
                      <span className="text-white font-mono">{formatCurrency(subtotal)}</span>
                    </div>

                    {pixDiscount > 0 && (
                      <div className="flex justify-between text-emerald-400">
                        <span>Desconto PIX (5%)</span>
                        <span className="font-mono">-{formatCurrency(pixDiscount)}</span>
                      </div>
                    )}

                    <div className="flex justify-between">
                      <span>Frete (Rio Branco / Brasil)</span>
                      <span className="font-mono text-white">
                        {isFreeShipping ? (
                          <span className="text-emerald-400 font-bold">GRÁTIS</span>
                        ) : (
                          formatCurrency(shippingCost)
                        )}
                      </span>
                    </div>

                    <div className="pt-3 border-t border-zinc-850 flex justify-between items-baseline text-white">
                      <span className="text-sm font-bold uppercase">Total Final</span>
                      <span className="text-xl font-mono font-black text-[#0066FF]">
                        {formatCurrency(finalTotal)}
                      </span>
                    </div>
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    className="w-full py-4 bg-[#0066FF] hover:bg-[#0055e6] text-white font-bold text-sm uppercase tracking-wider rounded-xl transition-all box-glow-blue flex items-center justify-center gap-2 shadow-xl"
                  >
                    <span>FINALIZAR PEDIDO</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <div className="pt-2 text-center text-[11px] text-zinc-500 flex items-center justify-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#0066FF]" />
                    <span>Ambiente Seguro · ZNK STORE01 Rio Branco</span>
                  </div>
                </div>
              </div>

            </form>
          )}
        </div>

      </div>
    </div>
  );
};
