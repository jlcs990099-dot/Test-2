import React, { useState, useEffect } from 'react';
import { Flame, Clock, ArrowRight, Sparkles, Tag, CheckCircle2 } from 'lucide-react';
import { PRODUCTS } from '../data/products';
import { Product } from '../types';
import { formatCurrency } from '../config/storeConfig';
import { useCart } from '../context/CartContext';
import { ScrollReveal } from './ScrollReveal';
import promoBannerImg from '../assets/images/znk_full_drop_caps_shirts_1791344001861.jpg';

interface PromoSectionProps {
  onViewProduct: (product: Product) => void;
}

export const PromoSection: React.FC<PromoSectionProps> = ({ onViewProduct }) => {
  const { addToCart } = useCart();
  
  // Promotional live demo countdown timer
  const [timeLeft, setTimeLeft] = useState({
    hours: 14,
    minutes: 36,
    seconds: 45,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return { hours: 12, minutes: 0, seconds: 0 };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const promoProducts = PRODUCTS.filter((p) => p.isPromo).slice(0, 4);

  return (
    <section id="promocoes" className="py-16 sm:py-24 border-b border-zinc-800/80 relative overflow-hidden bg-gradient-to-b from-[#090A0F] via-zinc-950 to-[#090A0F]">
      
      {/* Glow Effects */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-96 h-96 bg-[#0066FF]/15 blur-[130px] pointer-events-none rounded-full" />
      <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-[#0052FF]/10 blur-[110px] pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Main Promo Banner Card with ScrollReveal */}
        <ScrollReveal duration={750} distance={32}>
          <div className="relative rounded-3xl overflow-hidden border border-zinc-700/80 bg-zinc-950 p-6 sm:p-10 lg:p-12 mb-12 shadow-2xl">
            
            {/* Background Image with Streetwear Mood */}
            <div className="absolute inset-0 z-0">
              <img
                src={promoBannerImg}
                alt="Ofertas ZNK STORE01 - Streetwear em Rio Branco - AC"
                className="w-full h-full object-cover object-center opacity-25 filter brightness-75 scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-zinc-950 via-zinc-950/90 to-transparent" />
            </div>

            <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              
              <div className="lg:col-span-7 space-y-5">
                <div className="flex flex-wrap items-center gap-2">
                  <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#0066FF]/20 border border-[#0066FF]/50 text-white rounded-full text-xs font-bold uppercase tracking-wider">
                    <Flame className="w-3.5 h-3.5 text-[#3385ff]" />
                    <span>DROP OFICIAL ZNK STORE01</span>
                  </div>
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-950/80 border border-emerald-700/80 text-emerald-300 rounded-full text-xs font-medium">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Fotos 100% reais do estoque</span>
                  </div>
                </div>

                <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white font-heading uppercase tracking-tight leading-none">
                  OFERTAS DA <span className="text-[#0066FF] text-glow-blue">ZNK</span>
                </h2>

                <p className="text-base sm:text-xl text-zinc-300 font-medium">
                  Seu estilo novo pode estar aqui.
                </p>

                <p className="text-xs sm:text-sm text-zinc-400 max-w-lg">
                  Peças selecionadas com até 25% de desconto para elevar o visual na rua.
                  Qualidade premium, tecidos resistentes e corte exclusivo da ZNK STORE01.
                </p>

                {/* Countdown Timer Display */}
                <div className="pt-2">
                  <div className="flex items-center gap-2 text-xs font-mono text-zinc-400 mb-2.5">
                    <Clock className="w-3.5 h-3.5 text-[#0066FF]" />
                    <span>OFERTAS ENCERRAM EM:</span>
                  </div>

                  <div className="flex items-center gap-2.5 sm:gap-3">
                    <div className="flex flex-col items-center bg-zinc-900/90 border border-zinc-700/80 rounded-xl px-3 sm:px-4 py-2 min-w-[62px]">
                      <span className="font-mono text-xl sm:text-2xl font-black text-white">
                        {String(timeLeft.hours).padStart(2, '0')}
                      </span>
                      <span className="text-[10px] uppercase font-mono text-zinc-400">Horas</span>
                    </div>
                    <span className="text-lg font-bold text-zinc-600">:</span>
                    <div className="flex flex-col items-center bg-zinc-900/90 border border-zinc-700/80 rounded-xl px-3 sm:px-4 py-2 min-w-[62px]">
                      <span className="font-mono text-xl sm:text-2xl font-black text-white">
                        {String(timeLeft.minutes).padStart(2, '0')}
                      </span>
                      <span className="text-[10px] uppercase font-mono text-zinc-400">Min</span>
                    </div>
                    <span className="text-lg font-bold text-zinc-600">:</span>
                    <div className="flex flex-col items-center bg-zinc-900/90 border border-zinc-700/80 rounded-xl px-3 sm:px-4 py-2 min-w-[62px]">
                      <span className="font-mono text-xl sm:text-2xl font-black text-[#0066FF]">
                        {String(timeLeft.seconds).padStart(2, '0')}
                      </span>
                      <span className="text-[10px] uppercase font-mono text-zinc-400">Seg</span>
                    </div>
                  </div>
                </div>

                {/* CTA button */}
                <div className="pt-3">
                  <button
                    type="button"
                    onClick={() => {
                      const catalogEl = document.getElementById('produtos');
                      if (catalogEl) catalogEl.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="inline-flex items-center gap-2.5 px-8 py-3.5 bg-[#0066FF] hover:bg-[#0055e6] text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all box-glow-blue"
                  >
                    <Tag className="w-4 h-4" />
                    <span>APROVEITAR OFERTA</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

              </div>

              {/* Right highlight card on larger displays */}
              <div className="lg:col-span-5 hidden lg:block">
                <div className="p-6 rounded-2xl bg-zinc-950/80 border border-zinc-800/90 backdrop-blur-md">
                  <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 mb-2">
                    <Sparkles className="w-4 h-4" />
                    <span>CUPOM AUTOMÁTICO</span>
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2 font-heading">
                    5% OFF EXTRA NO PIX
                  </h3>
                  <p className="text-xs text-zinc-400 leading-relaxed mb-4">
                    Desconto acumulativo no checkout para qualquer item em promoção. Pagamento instantâneo e aprovação imediata para envio.
                  </p>
                  <div className="p-3 rounded-xl bg-zinc-900 border border-dashed border-zinc-700 flex items-center justify-between">
                    <span className="font-mono text-xs text-zinc-300">CÓDIGO: ZNKPIX5</span>
                    <span className="text-[11px] font-bold text-[#0066FF] uppercase">Automático</span>
                  </div>
                </div>
              </div>

            </div>

          </div>
        </ScrollReveal>

        {/* Selected Promo Products Showcase */}
        <div>
          <ScrollReveal duration={600} distance={20}>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg sm:text-xl font-bold text-white uppercase font-heading flex items-center gap-2">
                <Tag className="w-4 h-4 text-[#0066FF]" />
                <span>Peças com Desconto Imediato</span>
              </h3>
              <button
                type="button"
                onClick={() => {
                  const el = document.getElementById('produtos');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="text-xs font-semibold text-[#0066FF] hover:underline flex items-center gap-1"
              >
                <span>Ver todas as ofertas</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </ScrollReveal>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5">
            {promoProducts.map((product, index) => (
              <ScrollReveal
                key={product.id}
                delay={index * 80}
                duration={650}
                distance={28}
                className="h-full"
              >
                <div
                  onClick={() => onViewProduct(product)}
                  className="group cursor-pointer rounded-2xl bg-zinc-950 border border-zinc-800 hover:border-[#0066FF] p-3 flex flex-col justify-between transition-all duration-200 hover:-translate-y-1 hover:shadow-lg hover:shadow-[#0066FF]/10 h-full"
                >
                  <div className="aspect-square rounded-xl overflow-hidden relative bg-zinc-900 mb-3">
                    <img
                      src={product.images[0]}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      loading="lazy"
                    />
                    {product.discountPercent && (
                      <span className="absolute top-2 left-2 px-2 py-0.5 text-[10px] font-bold bg-[#0066FF] text-white rounded font-mono">
                        -{product.discountPercent}% OFF
                      </span>
                    )}
                  </div>

                  <div>
                    <span className="text-[10px] font-mono text-zinc-400 uppercase">
                      {product.category}
                    </span>
                    <h4 className="text-xs sm:text-sm font-bold text-white font-heading group-hover:text-[#3385ff] line-clamp-1 transition-colors">
                      {product.name}
                    </h4>
                    <div className="mt-1.5 flex items-baseline gap-2">
                      <span className="text-sm sm:text-base font-extrabold text-white font-mono">
                        {formatCurrency(product.price)}
                      </span>
                      {product.originalPrice && (
                        <span className="text-xs text-zinc-400 line-through font-mono">
                          {formatCurrency(product.originalPrice)}
                        </span>
                      )}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      addToCart(product, product.sizes[0] || 'M', 1);
                    }}
                    className="mt-3 w-full py-2 bg-zinc-900 hover:bg-[#0066FF] border border-zinc-800 hover:border-[#0066FF] text-white rounded-xl text-[11px] font-bold uppercase tracking-wider transition-colors"
                  >
                    Adicionar ao Carrinho
                  </button>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
