import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { generateWhatsAppLink, STORE_CONFIG } from '../config/storeConfig';

export const FloatingWhatsApp: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(true);

  const handleClick = () => {
    window.open(
      generateWhatsAppLink('Olá ZNK STORE01! Estava olhando o site e gostaria de tirar uma dúvida sobre os modelos e tamanhos.'),
      '_blank'
    );
  };

  return (
    <div className="fixed bottom-6 left-6 z-40 flex items-end gap-3 pointer-events-auto">
      {/* Floating Button - now on the left side */}
      <button
        type="button"
        onClick={handleClick}
        className="w-14 h-14 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center shadow-xl shadow-emerald-950/60 hover:scale-110 active:scale-95 transition-all duration-300 relative group shrink-0 ring-4 ring-emerald-500/20"
        aria-label="Abrir conversa no WhatsApp"
        title="Atendimento no WhatsApp"
      >
        <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-[#0066FF] rounded-full border-2 border-zinc-950 animate-pulse" />
        <MessageCircle className="w-7 h-7 fill-white text-emerald-600 group-hover:scale-105 transition-transform" />
      </button>

      {/* Tooltip speech bubble - positioned to the right of the button */}
      {showTooltip && (
        <div className="hidden sm:flex items-center gap-2 p-3 bg-zinc-950/95 backdrop-blur-md border border-zinc-800 rounded-2xl shadow-2xl text-xs text-zinc-200 animate-fade-in relative max-w-xs">
          {/* Speech bubble pointer arrow pointing to the left button */}
          <div className="absolute -left-1.5 bottom-5 w-3 h-3 bg-zinc-950 border-l border-b border-zinc-800 rotate-45" />

          <div className="flex flex-col relative z-10 pl-1">
            <span className="font-bold text-white flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              Equipe ZNK Online
            </span>
            <span className="text-[11px] text-zinc-400">
              Dúvidas de tamanhos ou entrega em Rio Branco? Fale conosco!
            </span>
          </div>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setShowTooltip(false);
            }}
            className="text-zinc-500 hover:text-zinc-300 p-1 relative z-10 shrink-0"
            aria-label="Fechar balão do WhatsApp"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};

